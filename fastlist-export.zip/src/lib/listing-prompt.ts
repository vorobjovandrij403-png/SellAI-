import { z } from "zod";

/** Shared schema + prompt building blocks for AI listing generation. */

export const listingSchema = z.object({
  title: z.string(),
  shortDescription: z.string(),
  fullDescription: z.string(),
  benefits: z.array(z.string()),
  seoTags: z.array(z.string()),
  olxTags: z.array(z.string()),
  promTags: z.array(z.string()),
  price: z.string(),
  facebook: z.string(),
  instagram: z.string(),
  platformPosts: z.object({
    olx: z.string(),
    prom: z.string(),
    instagram: z.string(),
  }),
  variants: z
    .array(
      z.object({
        code: z.string(),
        label: z.string(),
        title: z.string(),
        shortDescription: z.string(),
        fullDescription: z.string(),
        post: z.string(),
      })
    )
    .default([]),
});

export const languageInput = z.object({
  language: z.string().min(2).max(12).default("en"),
  extraLanguages: z.array(z.string().min(2).max(12)).max(10).default([]),
});

export const JSON_SHAPE = `{
  "title": string,
  "shortDescription": string,
  "fullDescription": string,
  "benefits": string[5],
  "seoTags": string[7],
  "olxTags": string[7],
  "promTags": string[7],
  "price": string,
  "facebook": string,
  "instagram": string,
  "platformPosts": { "olx": string, "prom": string, "instagram": string },
  "variants": [{ "code": string, "label": string, "title": string, "shortDescription": string, "fullDescription": string, "post": string }]
}`;

export function languageInstructions(
  language: string,
  extraLanguages: string[]
): string {
  const extras = extraLanguages.filter((code) => code !== language);
  const lines = [
    `Write ALL primary fields in the language with BCP-47 code "${language}". Use natural, idiomatic marketplace copy written by a native speaker of that language — never a literal translation.`,
  ];
  if (extras.length > 0) {
    lines.push(
      `Additionally fill "variants" with one entry per language code: ${extras.join(", ")}. Each entry must be original, natural selling copy written directly in that language (not a word-for-word translation), with "code" set to the code and "label" set to the language name written in that language.`
    );
  } else {
    lines.push(`Return "variants" as an empty array.`);
  }
  lines.push(
    `Prices: estimate a realistic market range for the seller's local market and keep it in the currency that fits the primary language (UAH for uk, EUR/PLN etc. otherwise). Tags: plain words, no "#" symbol. Reply with STRICT valid JSON only, no markdown fences.`
  );
  return lines.join("\n");
}

export function parseListingJson(raw: string) {
  const cleaned = raw
    .replace(/^\s*```(?:json)?/i, "")
    .replace(/```\s*$/, "")
    .trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start === -1 || end === -1) {
    throw new Error("AI returned an unexpected response");
  }
  return listingSchema.parse(JSON.parse(cleaned.slice(start, end + 1)));
}

export function aiErrorFor(status: number, body: string): Error {
  if (status === 429) return new Error("Too many requests — try again in a minute.");
  if (status === 402 || status === 403)
    return new Error("AI credits exhausted. Please top up in Lovable.");
  return new Error(`AI error (${status}): ${body.slice(0, 200)}`);
}
