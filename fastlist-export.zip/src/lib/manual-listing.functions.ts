import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import type { ListingData } from "./listing-types";
import {
  JSON_SHAPE,
  aiErrorFor,
  languageInput,
  languageInstructions,
  parseListingJson,
} from "./listing-prompt";

const inputSchema = languageInput.extend({
  name: z.string().trim().min(1).max(200),
  description: z.string().max(4000).default(""),
  price: z.string().max(60).default(""),
  category: z.string().max(120).default(""),
  specs: z.string().max(4000).default(""),
});

const SYSTEM_PROMPT = `You are an expert e-commerce copywriter for online marketplaces (OLX, Prom, Facebook, Instagram).
The seller entered product details manually. Use them as the source of truth, keep all facts and specs accurate, and write a persuasive, ready-to-post listing.
If the seller gave a price, use it as the recommended price (formatted nicely); otherwise estimate a realistic range.`;

export const generateListingFromManual = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => inputSchema.parse(data))
  .handler(async ({ data }): Promise<ListingData> => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) throw new Error("AI service is not configured");
    const { consumeListing } = await import("./usage.server");
    await consumeListing();

    const facts = [
      `Name: ${data.name}`,
      data.category && `Category: ${data.category}`,
      data.price && `Seller price: ${data.price}`,
      data.description && `Seller description: ${data.description}`,
      data.specs && `Specifications:\n${data.specs}`,
    ]
      .filter(Boolean)
      .join("\n");

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-3.7-flash",
        messages: [
          {
            role: "system",
            content: `${SYSTEM_PROMPT}\n${languageInstructions(data.language, data.extraLanguages)}`,
          },
          {
            role: "user",
            content: `Product details:\n${facts}\n\nReturn JSON exactly in this shape:\n${JSON_SHAPE}`,
          },
        ],
      }),
    });
    if (!res.ok) throw aiErrorFor(res.status, await res.text());
    const json = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
    return parseListingJson(json.choices?.[0]?.message?.content ?? "");
  });
