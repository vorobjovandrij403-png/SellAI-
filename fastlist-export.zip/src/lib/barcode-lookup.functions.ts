import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import type { ListingData } from "./listing-types";
import {
  JSON_SHAPE,
  aiErrorFor,
  languageInput,
  languageInstructions,
  parseListingJson,
} from "./listing-prompt";

const inputSchema = languageInput.extend({
  barcode: z
    .string()
    .trim()
    .regex(/^[0-9]{6,14}$/, "Invalid barcode"),
});

export type BarcodeLookupResult = {
  listing: ListingData;
  source: string;
  productName: string | null;
  brand: string | null;
};

type ProductFacts = {
  name?: string | undefined;
  brand?: string | undefined;
  category?: string | undefined;
  quantity?: string | undefined;
  ingredients?: string | undefined;
  description?: string | undefined;
  source: string;
};

async function fetchOpenFoodFacts(code: string): Promise<ProductFacts | null> {
  try {
    const res = await fetch(
      `https://world.openfoodfacts.org/api/v2/product/${code}.json`,
      { headers: { "User-Agent": "FastList/1.0 (listing generator)" } }
    );
    if (!res.ok) return null;
    const json = (await res.json()) as {
      status?: number;
      product?: Record<string, unknown>;
    };
    if (json.status !== 1 || !json.product) return null;
    const p = json.product;
    const str = (k: string) => {
      const v = p[k];
      return typeof v === "string" && v.trim() ? v.trim() : undefined;
    };
    return {
      name: str("product_name_uk") ?? str("product_name") ?? str("generic_name"),
      brand: str("brands"),
      category: str("categories"),
      quantity: str("quantity"),
      ingredients:
        str("ingredients_text_uk") ?? str("ingredients_text") ?? undefined,
      source: "Open Food Facts",
    };
  } catch {
    return null;
  }
}

async function fetchUpcItemDb(code: string): Promise<ProductFacts | null> {
  try {
    const res = await fetch(
      `https://api.upcitemdb.com/prod/trial/lookup?upc=${encodeURIComponent(code)}`
    );
    if (!res.ok) return null;
    const json = (await res.json()) as {
      items?: Array<Record<string, unknown>>;
    };
    const item = json.items?.[0];
    if (!item) return null;
    const str = (k: string) => {
      const v = item[k];
      return typeof v === "string" && v.trim() ? v.trim() : undefined;
    };
    return {
      name: str("title"),
      brand: str("brand"),
      category: str("category"),
      description: str("description"),
      source: "UPCitemdb",
    };
  } catch {
    return null;
  }
}

const SYSTEM_PROMPT = `You are an expert e-commerce copywriter for online marketplaces (OLX, Prom, Instagram).
You receive a product barcode plus whatever facts product databases know about it.
Use those facts (name, brand, category, volume/weight, ingredients) together with your own knowledge of the product and typical market prices to write a complete, persuasive listing.`;

export const generateListingFromBarcode = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => inputSchema.parse(data))
  .handler(async ({ data }): Promise<BarcodeLookupResult> => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) throw new Error("AI service is not configured");
    const { consumeListing } = await import("./usage.server");
    await consumeListing();

    const facts =
      (await fetchOpenFoodFacts(data.barcode)) ??
      (await fetchUpcItemDb(data.barcode));

    const known = facts
      ? [
          facts.name && `Name: ${facts.name}`,
          facts.brand && `Brand: ${facts.brand}`,
          facts.category && `Category: ${facts.category}`,
          facts.quantity && `Volume/weight: ${facts.quantity}`,
          facts.ingredients && `Ingredients: ${facts.ingredients}`,
          facts.description && `Description: ${facts.description}`,
        ]
          .filter(Boolean)
          .join("\n")
      : "No data found in open product databases — identify the product from the barcode and your own knowledge.";

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3.7-flash",
        messages: [
          {
            role: "system",
            content: `${SYSTEM_PROMPT}\n${languageInstructions(data.language, data.extraLanguages)}`,
          },
          {
            role: "user",
            content: `Barcode: ${data.barcode}\nKnown product-database facts (${facts?.source ?? "none"}):\n${known}\n\nReturn JSON exactly in this shape:\n${JSON_SHAPE}`,
          },
        ],
      }),
    });

    if (!res.ok) throw aiErrorFor(res.status, await res.text());

    const json = (await res.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    const raw = json.choices?.[0]?.message?.content ?? "";

    return {
      listing: parseListingJson(raw),
      source: facts?.source ?? "AI estimate from barcode",
      productName: facts?.name ?? null,
      brand: facts?.brand ?? null,
    };
  });
