import { createHmac } from "node:crypto";

export const PLANS = {
  start: { name: "FastList START", amount: 4.99, limit: 30 },
  pro: { name: "FastList PRO", amount: 9.99, limit: 100 },
  business: { name: "FastList BUSINESS", amount: 19.99, limit: 500 },
} as const;
export type PlanId = keyof typeof PLANS;
export const FREE_LIMIT = 3;
export const TRIAL_DAYS = 10;
export const CURRENCY = "EUR";

// Public WayForPay test merchant — used until real credentials are saved.
const TEST_MERCHANT = {
  account: "test_merch_n1",
  secret: "flk3409refn54t54t*FNJRET",
  domain: "www.market.ua",
};

export function wfpConfig() {
  const account = process.env["WAYFORPAY_MERCHANT_ACCOUNT"];
  const secret = process.env["WAYFORPAY_SECRET_KEY"];
  const domain = process.env["WAYFORPAY_DOMAIN"];
  if (account && secret) {
    return { account, secret, domain: domain || "fastlist.app", test: false };
  }
  return { ...TEST_MERCHANT, test: true };
}

export function wfpSign(parts: Array<string | number>, secret: string) {
  return createHmac("md5", secret).update(parts.join(";"), "utf8").digest("hex");
}

export function addDays(date: Date, days: number) {
  return new Date(date.getTime() + days * 86_400_000);
}
