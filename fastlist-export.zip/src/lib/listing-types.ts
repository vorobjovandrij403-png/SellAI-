export type Platform = "olx" | "prom" | "instagram";

export type ListingVariant = {
  /** Language code from the i18n catalogue */
  code: string;
  /** Language name in that language */
  label: string;
  title: string;
  shortDescription: string;
  fullDescription: string;
  post: string;
};

export type ListingData = {
  title: string;
  shortDescription: string;
  fullDescription: string;
  benefits: string[];
  seoTags: string[];
  olxTags: string[];
  promTags: string[];
  price: string;
  facebook: string;
  instagram: string;
  platformPosts: Record<Platform, string>;
  /** Natural (non-literal) versions of the listing in other languages */
  variants: ListingVariant[];
};
