import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import type { ListingData } from "./listing-types";
import {
  JSON_SHAPE,
  aiErrorFor,
  languageInput,
  languageInstructions,
  parseListingJson,
} from "./listing-prompt";

const inputSchema = languageInput.extend({
  imageDataUrl: z
    .string()
    .startsWith("data:image/")
    .max(8_000_000, "Image too large"),
});

const SYSTEM_PROMPT = `You are an expert e-commerce copywriter for online marketplaces (OLX, Prom, Facebook, Instagram).
The photo shows a product. Read the label, brand name, ingredients, volume or weight, and any text on the packaging.
Based on what you see, write a persuasive, ready-to-post listing.
If ingredients or composition are visible, mention the key ones in the full description and benefits.`;

export const generateListingFromImage = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => inputSchema.parse(data))
  .handler(async ({ data }): Promise<ListingData> => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) throw new Error("AI service is not configured");
    const { consumeListing } = await import("./usage.server");
    await consumeListing();

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3.7-flash",
        messages: [
          {
            role: "system",
            content: `${SYSTEM_PROMPT}\n${languageInstructions(data.language, data.extraLanguages)}`,
          },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: `Read the product label and composition on the photo and return JSON exactly in this shape:\n${JSON_SHAPE}`,
              },
              { type: "image_url", image_url: { url: data.imageDataUrl } },
            ],
          },
        ],
      }),
    });

    if (!res.ok) throw aiErrorFor(res.status, await res.text());

    const json = (await res.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    return parseListingJson(json.choices?.[0]?.message?.content ?? "");
  });
