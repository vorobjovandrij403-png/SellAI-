import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

import {
  DEFAULT_LANGUAGE,
  LANGUAGE_BY_CODE,
  resolveLanguage,
  type LanguageMeta,
} from "./languages";
import { dictionaries, en, type TranslationKey } from "./translations";

const STORAGE_KEY = "fastlist.language";

type Vars = Record<string, string | number>;

type I18nValue = {
  language: string;
  meta: LanguageMeta | undefined;
  setLanguage: (code: string) => void;
  t: (key: TranslationKey, vars?: Vars) => string;
};

const I18nContext = createContext<I18nValue | null>(null);

function interpolate(template: string, vars?: Vars): string {
  if (!vars) return template;
  return template.replace(/\{(\w+)\}/g, (match, name: string) => {
    const value = vars[name];
    return value === undefined ? match : String(value);
  });
}

function detectLanguage(): string {
  if (typeof window === "undefined") return DEFAULT_LANGUAGE;
  try {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (saved && LANGUAGE_BY_CODE[saved]) return saved;
  } catch {
    /* storage unavailable */
  }
  const candidates = [
    ...(navigator.languages ?? []),
    navigator.language,
  ].filter(Boolean) as string[];
  for (const candidate of candidates) {
    const resolved = resolveLanguage(candidate);
    if (resolved) return resolved;
  }
  return DEFAULT_LANGUAGE;
}

export function I18nProvider({ children }: { children: ReactNode }) {
  // SSR renders the fallback locale; detection happens after hydration.
  const [language, setLanguageState] = useState<string>(DEFAULT_LANGUAGE);

  useEffect(() => {
    setLanguageState(detectLanguage());
  }, []);

  useEffect(() => {
    const meta = LANGUAGE_BY_CODE[language];
    document.documentElement.lang = language;
    document.documentElement.dir = meta?.rtl ? "rtl" : "ltr";
  }, [language]);

  const setLanguage = useCallback((code: string) => {
    if (!LANGUAGE_BY_CODE[code]) return;
    setLanguageState(code);
    try {
      window.localStorage.setItem(STORAGE_KEY, code);
    } catch {
      /* storage unavailable */
    }
  }, []);

  const t = useCallback(
    (key: TranslationKey, vars?: Vars) => {
      const base = language.split("-")[0] ?? language;
      const template =
        dictionaries[language]?.[key] ??
        dictionaries[base]?.[key] ??
        en[key] ??
        key;
      return interpolate(template, vars);
    },
    [language]
  );

  const value = useMemo<I18nValue>(
    () => ({ language, meta: LANGUAGE_BY_CODE[language], setLanguage, t }),
    [language, setLanguage, t]
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nValue {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used inside <I18nProvider>");
  return ctx;
}

export type { TranslationKey };
export * from "./languages";
