export type LanguageMeta = {
  /** BCP-47 base code */
  code: string;
  /** Name written in the language itself */
  native: string;
  /** English name, used for search */
  english: string;
  /** Country flag emoji, where a flag is meaningful */
  flag?: string;
  rtl?: boolean;
};

/**
 * Catalogue of languages the product can operate in (UI + AI output).
 * Adding a language = adding one row here. UI strings fall back to English
 * automatically until a dictionary for the code exists.
 */
export const LANGUAGES: LanguageMeta[] = [
  { code: "uk", native: "Українська", english: "Ukrainian", flag: "🇺🇦" },
  { code: "en", native: "English", english: "English", flag: "🇬🇧" },
  { code: "pl", native: "Polski", english: "Polish", flag: "🇵🇱" },
  { code: "de", native: "Deutsch", english: "German", flag: "🇩🇪" },
  { code: "fr", native: "Français", english: "French", flag: "🇫🇷" },
  { code: "es", native: "Español", english: "Spanish", flag: "🇪🇸" },
  { code: "it", native: "Italiano", english: "Italian", flag: "🇮🇹" },
  { code: "pt", native: "Português", english: "Portuguese", flag: "🇵🇹" },
  { code: "pt-BR", native: "Português (Brasil)", english: "Portuguese (Brazil)", flag: "🇧🇷" },
  { code: "nl", native: "Nederlands", english: "Dutch", flag: "🇳🇱" },
  { code: "cs", native: "Čeština", english: "Czech", flag: "🇨🇿" },
  { code: "sk", native: "Slovenčina", english: "Slovak", flag: "🇸🇰" },
  { code: "ro", native: "Română", english: "Romanian", flag: "🇷🇴" },
  { code: "hu", native: "Magyar", english: "Hungarian", flag: "🇭🇺" },
  { code: "tr", native: "Türkçe", english: "Turkish", flag: "🇹🇷" },
  { code: "sv", native: "Svenska", english: "Swedish", flag: "🇸🇪" },
  { code: "no", native: "Norsk", english: "Norwegian", flag: "🇳🇴" },
  { code: "fi", native: "Suomi", english: "Finnish", flag: "🇫🇮" },
  { code: "da", native: "Dansk", english: "Danish", flag: "🇩🇰" },
  { code: "is", native: "Íslenska", english: "Icelandic", flag: "🇮🇸" },
  { code: "el", native: "Ελληνικά", english: "Greek", flag: "🇬🇷" },
  { code: "bg", native: "Български", english: "Bulgarian", flag: "🇧🇬" },
  { code: "hr", native: "Hrvatski", english: "Croatian", flag: "🇭🇷" },
  { code: "sr", native: "Српски", english: "Serbian", flag: "🇷🇸" },
  { code: "bs", native: "Bosanski", english: "Bosnian", flag: "🇧🇦" },
  { code: "mk", native: "Македонски", english: "Macedonian", flag: "🇲🇰" },
  { code: "sl", native: "Slovenščina", english: "Slovenian", flag: "🇸🇮" },
  { code: "sq", native: "Shqip", english: "Albanian", flag: "🇦🇱" },
  { code: "lt", native: "Lietuvių", english: "Lithuanian", flag: "🇱🇹" },
  { code: "lv", native: "Latviešu", english: "Latvian", flag: "🇱🇻" },
  { code: "et", native: "Eesti", english: "Estonian", flag: "🇪🇪" },
  { code: "ru", native: "Русский", english: "Russian", flag: "🇷🇺" },
  { code: "be", native: "Беларуская", english: "Belarusian", flag: "🇧🇾" },
  { code: "ka", native: "ქართული", english: "Georgian", flag: "🇬🇪" },
  { code: "hy", native: "Հայերեն", english: "Armenian", flag: "🇦🇲" },
  { code: "az", native: "Azərbaycan", english: "Azerbaijani", flag: "🇦🇿" },
  { code: "kk", native: "Қазақша", english: "Kazakh", flag: "🇰🇿" },
  { code: "uz", native: "Oʻzbekcha", english: "Uzbek", flag: "🇺🇿" },
  { code: "ky", native: "Кыргызча", english: "Kyrgyz", flag: "🇰🇬" },
  { code: "tg", native: "Тоҷикӣ", english: "Tajik", flag: "🇹🇯" },
  { code: "tk", native: "Türkmençe", english: "Turkmen", flag: "🇹🇲" },
  { code: "mn", native: "Монгол", english: "Mongolian", flag: "🇲🇳" },
  { code: "zh-Hans", native: "简体中文", english: "Chinese (Simplified)", flag: "🇨🇳" },
  { code: "zh-Hant", native: "繁體中文", english: "Chinese (Traditional)", flag: "🇹🇼" },
  { code: "yue", native: "粵語", english: "Cantonese", flag: "🇭🇰" },
  { code: "ja", native: "日本語", english: "Japanese", flag: "🇯🇵" },
  { code: "ko", native: "한국어", english: "Korean", flag: "🇰🇷" },
  { code: "hi", native: "हिन्दी", english: "Hindi", flag: "🇮🇳" },
  { code: "bn", native: "বাংলা", english: "Bengali", flag: "🇧🇩" },
  { code: "ur", native: "اردو", english: "Urdu", flag: "🇵🇰", rtl: true },
  { code: "pa", native: "ਪੰਜਾਬੀ", english: "Punjabi", flag: "🇮🇳" },
  { code: "gu", native: "ગુજરાતી", english: "Gujarati", flag: "🇮🇳" },
  { code: "mr", native: "मराठी", english: "Marathi", flag: "🇮🇳" },
  { code: "ta", native: "தமிழ்", english: "Tamil", flag: "🇮🇳" },
  { code: "te", native: "తెలుగు", english: "Telugu", flag: "🇮🇳" },
  { code: "kn", native: "ಕನ್ನಡ", english: "Kannada", flag: "🇮🇳" },
  { code: "ml", native: "മലയാളം", english: "Malayalam", flag: "🇮🇳" },
  { code: "or", native: "ଓଡ଼ିଆ", english: "Odia", flag: "🇮🇳" },
  { code: "as", native: "অসমীয়া", english: "Assamese", flag: "🇮🇳" },
  { code: "ne", native: "नेपाली", english: "Nepali", flag: "🇳🇵" },
  { code: "si", native: "සිංහල", english: "Sinhala", flag: "🇱🇰" },
  { code: "my", native: "မြန်မာ", english: "Burmese", flag: "🇲🇲" },
  { code: "km", native: "ខ្មែរ", english: "Khmer", flag: "🇰🇭" },
  { code: "lo", native: "ລາວ", english: "Lao", flag: "🇱🇦" },
  { code: "th", native: "ไทย", english: "Thai", flag: "🇹🇭" },
  { code: "vi", native: "Tiếng Việt", english: "Vietnamese", flag: "🇻🇳" },
  { code: "id", native: "Bahasa Indonesia", english: "Indonesian", flag: "🇮🇩" },
  { code: "ms", native: "Bahasa Melayu", english: "Malay", flag: "🇲🇾" },
  { code: "tl", native: "Filipino", english: "Filipino", flag: "🇵🇭" },
  { code: "jv", native: "Basa Jawa", english: "Javanese", flag: "🇮🇩" },
  { code: "ar", native: "العربية", english: "Arabic", flag: "🇸🇦", rtl: true },
  { code: "he", native: "עברית", english: "Hebrew", flag: "🇮🇱", rtl: true },
  { code: "fa", native: "فارسی", english: "Persian", flag: "🇮🇷", rtl: true },
  { code: "ps", native: "پښتو", english: "Pashto", flag: "🇦🇫", rtl: true },
  { code: "ku", native: "Kurdî", english: "Kurdish", flag: "🇮🇶" },
  { code: "sw", native: "Kiswahili", english: "Swahili", flag: "🇰🇪" },
  { code: "am", native: "አማርኛ", english: "Amharic", flag: "🇪🇹" },
  { code: "ha", native: "Hausa", english: "Hausa", flag: "🇳🇬" },
  { code: "yo", native: "Yorùbá", english: "Yoruba", flag: "🇳🇬" },
  { code: "ig", native: "Igbo", english: "Igbo", flag: "🇳🇬" },
  { code: "zu", native: "isiZulu", english: "Zulu", flag: "🇿🇦" },
  { code: "xh", native: "isiXhosa", english: "Xhosa", flag: "🇿🇦" },
  { code: "af", native: "Afrikaans", english: "Afrikaans", flag: "🇿🇦" },
  { code: "so", native: "Soomaali", english: "Somali", flag: "🇸🇴" },
  { code: "mg", native: "Malagasy", english: "Malagasy", flag: "🇲🇬" },
  { code: "rw", native: "Kinyarwanda", english: "Kinyarwanda", flag: "🇷🇼" },
  { code: "ga", native: "Gaeilge", english: "Irish", flag: "🇮🇪" },
  { code: "cy", native: "Cymraeg", english: "Welsh", flag: "🏴󠁧󠁢󠁷󠁬󠁳󠁿" },
  { code: "gd", native: "Gàidhlig", english: "Scottish Gaelic", flag: "🏴󠁧󠁢󠁳󠁣󠁴󠁿" },
  { code: "ca", native: "Català", english: "Catalan", flag: "🇦🇩" },
  { code: "gl", native: "Galego", english: "Galician", flag: "🇪🇸" },
  { code: "eu", native: "Euskara", english: "Basque", flag: "🇪🇸" },
  { code: "mt", native: "Malti", english: "Maltese", flag: "🇲🇹" },
  { code: "lb", native: "Lëtzebuergesch", english: "Luxembourgish", flag: "🇱🇺" },
  { code: "fo", native: "Føroyskt", english: "Faroese", flag: "🇫🇴" },
  { code: "la", native: "Latina", english: "Latin" },
  { code: "eo", native: "Esperanto", english: "Esperanto" },
  { code: "haw", native: "ʻŌlelo Hawaiʻi", english: "Hawaiian", flag: "🇺🇸" },
  { code: "mi", native: "Te Reo Māori", english: "Maori", flag: "🇳🇿" },
  { code: "sm", native: "Gagana Samoa", english: "Samoan", flag: "🇼🇸" },
  { code: "qu", native: "Runa Simi", english: "Quechua", flag: "🇵🇪" },
  { code: "gn", native: "Avañeʼẽ", english: "Guarani", flag: "🇵🇾" },
  { code: "ht", native: "Kreyòl Ayisyen", english: "Haitian Creole", flag: "🇭🇹" },
];

export const LANGUAGE_BY_CODE: Record<string, LanguageMeta> = Object.fromEntries(
  LANGUAGES.map((l) => [l.code, l])
);

export const DEFAULT_LANGUAGE = "en";

/** Map any browser locale (e.g. "pt-BR", "zh-TW", "uk-UA") to a catalogue code. */
export function resolveLanguage(locale: string | undefined | null): string | null {
  if (!locale) return null;
  const tag = locale.trim();
  if (!tag) return null;
  if (LANGUAGE_BY_CODE[tag]) return tag;

  const lower = tag.toLowerCase();
  const exact = LANGUAGES.find((l) => l.code.toLowerCase() === lower);
  if (exact) return exact.code;

  if (lower.startsWith("zh")) {
    return /hant|tw|hk|mo/.test(lower) ? "zh-Hant" : "zh-Hans";
  }
  if (lower.startsWith("pt")) return lower.includes("br") ? "pt-BR" : "pt";

  const base = lower.split(/[-_]/)[0] ?? "";
  const match = LANGUAGES.find((l) => l.code.toLowerCase() === base);
  return match ? match.code : null;
}

export function searchLanguages(query: string): LanguageMeta[] {
  const q = query.trim().toLowerCase();
  if (!q) return LANGUAGES;
  return LANGUAGES.filter(
    (l) =>
      l.native.toLowerCase().includes(q) ||
      l.english.toLowerCase().includes(q) ||
      l.code.toLowerCase().includes(q)
  );
}
