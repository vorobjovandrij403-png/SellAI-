import { getRequestHeader } from "@tanstack/react-start/server";
import { FREE_LIMIT, PLANS, type PlanId } from "./wayforpay.server";

export function currentPeriod() {
  return new Date().toISOString().slice(0, 7);
}

export async function limitForUser(
  admin: Awaited<typeof import("@/integrations/supabase/client.server")>["supabaseAdmin"],
  userId: string
) {
  const { data } = await admin
    .from("subscriptions")
    .select("plan,status,current_period_end")
    .eq("user_id", userId)
    .in("status", ["trialing", "active"])
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (data && (!data.current_period_end || new Date(data.current_period_end) > new Date())) {
    return PLANS[data.plan as PlanId]?.limit ?? FREE_LIMIT;
  }
  return FREE_LIMIT;
}

/** Counts one generated listing for a signed-in user; throws when the monthly limit is reached. Anonymous demo use is not counted. */
export async function consumeListing() {
  const auth = getRequestHeader("authorization");
  const token = auth?.startsWith("Bearer ") ? auth.slice(7) : null;
  if (!token) return;
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: userData } = await supabaseAdmin.auth.getUser(token);
  const userId = userData.user?.id;
  if (!userId) return;

  const limit = await limitForUser(supabaseAdmin, userId);
  const period = currentPeriod();
  const { data: row } = await supabaseAdmin
    .from("usage")
    .select("count")
    .eq("user_id", userId)
    .eq("period", period)
    .maybeSingle();
  const used = row?.count ?? 0;
  if (used >= limit) {
    throw new Error("LIMIT_REACHED");
  }
  await supabaseAdmin
    .from("usage")
    .upsert({ user_id: userId, period, count: used + 1 });
}
