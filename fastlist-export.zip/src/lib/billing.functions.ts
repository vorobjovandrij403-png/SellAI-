import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const checkoutInput = z.object({
  plan: z.enum(["start", "pro", "business"]),
  fullName: z.string().trim().min(2).max(100),
  phone: z.string().trim().min(6).max(20),
  returnOrigin: z.string().url(),
});

export type CheckoutForm = { action: string; fields: Record<string, string> };

export const createCheckout = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => checkoutInput.parse(d))
  .handler(async ({ data, context }): Promise<CheckoutForm> => {
    const { PLANS, CURRENCY, wfpConfig, wfpSign } = await import("./wayforpay.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const cfg = wfpConfig();
    const plan = PLANS[data.plan];
    const email = (context.claims as { email?: string }).email ?? "";
    const orderReference = `FL-${data.plan}-${context.userId.slice(0, 8)}-${Date.now()}`;

    await supabaseAdmin.from("profiles").upsert({
      id: context.userId,
      email,
      full_name: data.fullName,
      phone: data.phone,
    });
    const { error } = await supabaseAdmin.from("subscriptions").insert({
      user_id: context.userId,
      plan: data.plan,
      status: "pending",
      order_reference: orderReference,
      amount: plan.amount,
      currency: CURRENCY,
    });
    if (error) throw new Error("Could not start checkout");

    const origin = new URL(data.returnOrigin).origin;
    const [first, ...rest] = data.fullName.split(" ");
    // Card verification (1 UAH hold, refunded) — returns a recToken for later monthly charges.
    const amount = "1";
    const currency = "UAH";
    const fields: Record<string, string> = {
      merchantAccount: cfg.account,
      merchantDomainName: cfg.domain,
      merchantAuthType: "SimpleSignature",
      orderReference,
      amount,
      currency,
      paymentSystem: "card;googlePay;applePay",
      clientFirstName: first ?? "",
      clientLastName: rest.join(" ") || (first ?? ""),
      clientEmail: email,
      clientPhone: data.phone,
      language: "UA",
      returnUrl: `${origin}/api/public/wayforpay/return?order=${encodeURIComponent(orderReference)}`,
      serviceUrl: `${origin}/api/public/wayforpay/callback`,
    };
    fields["merchantSignature"] = wfpSign(
      [cfg.account, cfg.domain, orderReference, amount, currency],
      cfg.secret
    );
    return { action: "https://secure.wayforpay.com/verify", fields };
  });

export type BillingState = {
  plan: string | null;
  status: string | null;
  trialEndsAt: string | null;
  periodEnd: string | null;
  used: number;
  limit: number;
};

export const getMyBilling = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<BillingState> => {
    const { PLANS, FREE_LIMIT } = await import("./wayforpay.server");
    const { data: sub } = await context.supabase
      .from("subscriptions")
      .select("plan,status,trial_ends_at,current_period_end")
      .eq("user_id", context.userId)
      .in("status", ["trialing", "active", "canceled"])
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    const period = new Date().toISOString().slice(0, 7);
    const { data: usage } = await context.supabase
      .from("usage")
      .select("count")
      .eq("user_id", context.userId)
      .eq("period", period)
      .maybeSingle();
    const live =
      sub && (!sub.current_period_end || new Date(sub.current_period_end) > new Date());
    return {
      plan: live ? sub.plan : null,
      status: live ? sub.status : null,
      trialEndsAt: live ? sub.trial_ends_at : null,
      periodEnd: live ? sub.current_period_end : null,
      used: usage?.count ?? 0,
      limit: live ? (PLANS[sub.plan as keyof typeof PLANS]?.limit ?? FREE_LIMIT) : FREE_LIMIT,
    };
  });

export const getOrderStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ order: z.string().max(120) }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: sub } = await context.supabase
      .from("subscriptions")
      .select("plan,status,trial_ends_at")
      .eq("order_reference", data.order)
      .maybeSingle();
    return sub ?? null;
  });

export const cancelSubscription = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // Access stays until the paid/trial period ends; no further charges are made.
    await supabaseAdmin
      .from("subscriptions")
      .update({ status: "canceled", updated_at: new Date().toISOString() })
      .eq("user_id", context.userId)
      .in("status", ["trialing", "active"]);
    return { ok: true };
  });
