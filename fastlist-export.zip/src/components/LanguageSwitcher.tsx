import { useMemo, useState } from "react";
import { Check, Globe, Search, X } from "lucide-react";

import { useI18n, LANGUAGES, searchLanguages } from "@/lib/i18n";

export default function LanguageSwitcher() {
  const { language, meta, setLanguage, t } = useI18n();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  const results = useMemo(() => searchLanguages(query), [query]);

  return (
    <>
      <button
        onClick={() => {
          setQuery("");
          setOpen(true);
        }}
        className="flex shrink-0 items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-[12px] font-semibold text-ink/80 shadow-sm transition hover:border-brand/40 hover:text-brand active:scale-95"
        aria-label={t("lang.button")}
      >
        <Globe className="size-4 text-brand" />
        <span>{meta?.flag ?? "🌐"}</span>
        <span className="max-w-[86px] truncate">{meta?.native ?? "Language"}</span>
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/50 backdrop-blur-sm sm:items-center sm:p-4">
          <div className="flex h-[85vh] w-full max-w-[414px] flex-col rounded-t-2xl bg-card shadow-xl sm:h-[70vh] sm:rounded-2xl">
            <div className="flex items-center justify-between gap-3 border-b border-border p-4">
              <div className="min-w-0">
                <h2 className="font-display text-base font-bold text-ink">
                  {t("lang.dialogTitle")}
                </h2>
                <p className="text-[11px] text-ink/50">
                  {t("lang.count", { count: LANGUAGES.length })}
                </p>
              </div>
              <button
                onClick={() => setOpen(false)}
                aria-label={t("common.close")}
                className="grid size-8 shrink-0 place-items-center rounded-full bg-sand text-ink/60 transition hover:bg-muted"
              >
                <X className="size-4" />
              </button>
            </div>

            <div className="p-3">
              <div className="flex items-center gap-2 rounded-lg border border-input bg-card px-3 py-2.5">
                <Search className="size-4 shrink-0 text-ink/40" />
                <input
                  autoFocus
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder={t("lang.search")}
                  className="w-full bg-transparent text-sm text-ink outline-none placeholder:text-ink/40"
                />
              </div>
            </div>

            <div className="min-h-0 flex-1 overflow-y-auto px-3 pb-4">
              {results.length === 0 ? (
                <p className="px-2 py-6 text-center text-sm text-ink/50">
                  {t("lang.noResults")}
                </p>
              ) : (
                <ul className="space-y-1">
                  {results.map((item) => {
                    const active = item.code === language;
                    return (
                      <li key={item.code}>
                        <button
                          onClick={() => {
                            setLanguage(item.code);
                            setOpen(false);
                          }}
                          className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left transition ${
                            active
                              ? "bg-brand/10 text-brand"
                              : "text-ink/80 hover:bg-sand"
                          }`}
                        >
                          <span className="w-6 shrink-0 text-lg leading-none">
                            {item.flag ?? "🌐"}
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-sm font-semibold">
                              {item.native}
                            </span>
                            <span className="block truncate text-[11px] text-ink/45">
                              {item.english}
                            </span>
                          </span>
                          {active && <Check className="size-4 shrink-0" />}
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
