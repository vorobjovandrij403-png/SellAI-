import { useState } from "react";
import { X, ShieldCheck, CreditCard } from "lucide-react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";

import { useI18n } from "@/lib/i18n";
import { createCheckout } from "@/lib/billing.functions";

export type CheckoutPlan = {
  id: "start" | "pro" | "business";
  name: string;
  price: string;
  period: string;
  description: string;
  trialDays: number;
};

type Props = {
  plan: CheckoutPlan;
  email: string;
  onClose: () => void;
};

const inputCls =
  "mt-1 w-full rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-ink outline-none focus:border-brand";
const labelCls = "text-[11px] font-semibold uppercase tracking-wider text-ink/50";

function postToWayForPay(action: string, fields: Record<string, string>) {
  const form = document.createElement("form");
  form.method = "POST";
  form.action = action;
  form.acceptCharset = "utf-8";
  for (const [k, v] of Object.entries(fields)) {
    const input = document.createElement("input");
    input.type = "hidden";
    input.name = k;
    input.value = v;
    form.appendChild(input);
  }
  document.body.appendChild(form);
  form.submit();
}

export default function CheckoutModal({ plan, email, onClose }: Props) {
  const { t } = useI18n();
  const start = useServerFn(createCheckout);
  const [submitting, setSubmitting] = useState(false);
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await start({
        data: { plan: plan.id, fullName, phone, returnOrigin: window.location.origin },
      });
      postToWayForPay(res.action, res.fields);
    } catch {
      toast.error(t("checkout.failed"));
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/50 p-0 backdrop-blur-sm sm:items-center sm:p-4">
      <div className="w-full max-w-[414px] rounded-t-2xl bg-card p-5 shadow-xl sm:rounded-2xl">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="font-display text-lg font-bold text-ink">{t("checkout.title")}</h3>
            <p className="mt-0.5 text-xs text-ink/60">
              {plan.name} · {plan.description}
            </p>
          </div>
          <button
            onClick={onClose}
            aria-label={t("common.close")}
            className="grid size-8 place-items-center rounded-full bg-sand text-ink/60 transition hover:bg-muted"
          >
            <X className="size-4" />
          </button>
        </div>

        <div className="mt-4 rounded-xl border border-brand/25 bg-brand/5 p-3">
          <p className="text-sm font-bold text-brand">{t("checkout.trial", { days: plan.trialDays })}</p>
          <p className="mt-0.5 text-xs text-ink/60">
            {t("checkout.after", { price: plan.price, period: plan.period })}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-3">
          <div>
            <label htmlFor="checkout-name" className={labelCls}>{t("checkout.name")}</label>
            <input id="checkout-name" required minLength={2} autoComplete="name" value={fullName} onChange={(e) => setFullName(e.target.value)} className={inputCls} />
          </div>
          <div>
            <label htmlFor="checkout-email" className={labelCls}>{t("checkout.email")}</label>
            <input id="checkout-email" type="email" value={email} readOnly className={`${inputCls} bg-sand text-ink/60`} />
          </div>
          <div>
            <label htmlFor="checkout-phone" className={labelCls}>{t("checkout.phone")}</label>
            <input id="checkout-phone" type="tel" required minLength={6} autoComplete="tel" placeholder="+380" value={phone} onChange={(e) => setPhone(e.target.value)} className={inputCls} />
          </div>

          <div className="rounded-xl bg-sand p-3">
            <p className="flex items-center gap-2 text-xs font-semibold text-ink/70">
              <CreditCard className="size-4 text-brand" />
              {t("checkout.secureCard")}
            </p>
            <p className="mt-1 text-[11px] text-ink/50">{t("checkout.verifyNote")}</p>
            <p className="mt-1 text-[11px] text-ink/50">Visa · Mastercard · Apple Pay · Google Pay</p>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full rounded-lg bg-brand py-3 text-sm font-bold text-brand-foreground shadow-sm shadow-brand/25 transition hover:bg-brand-deep active:scale-[0.99] disabled:opacity-70"
          >
            {submitting ? t("checkout.submitting") : t("checkout.submit", { days: plan.trialDays })}
          </button>

          <p className="flex items-center justify-center gap-1.5 text-[11px] text-ink/45">
            <ShieldCheck className="size-3.5" />
            {t("checkout.secure")}
          </p>
        </form>
      </div>
    </div>
  );
}
