import { useCallback, useEffect, useRef, useState } from "react";
import { X, ScanLine, Camera, RefreshCw } from "lucide-react";

import { useI18n, type TranslationKey } from "@/lib/i18n";

type Props = {
  onCapture: (dataUrl: string) => void;
  onClose: () => void;
  mode?: "photo" | "barcode";
  onBarcode?: (code: string) => void;
};

type BarcodeDetectorLike = {
  detect: (source: CanvasImageSource) => Promise<Array<{ rawValue: string }>>;
};


const SAMPLE_W = 64;
const SAMPLE_H = 48;
const STABLE_FRAMES = 5; // ~1s at 200ms
const MOTION_THRESHOLD = 7; // mean abs luma diff
const SHARPNESS_THRESHOLD = 90; // luma variance — filters blank/blurred frames

export default function CameraScanner({ onCapture, onClose, mode = "photo", onBarcode }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const prevRef = useRef<Float32Array | null>(null);
  const stableRef = useRef(0);
  const capturedRef = useRef(false);

  const { t } = useI18n();

  const [error, setError] = useState<TranslationKey | null>(null);
  const [ready, setReady] = useState(false);
  const [progress, setProgress] = useState(0);
  const [hint, setHint] = useState<TranslationKey>("scanner.hint.point");

  const stopStream = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  }, []);

  const capture = useCallback(() => {
    const video = videoRef.current;
    if (!video || capturedRef.current) return;
    capturedRef.current = true;

    const canvas = document.createElement("canvas");
    const w = video.videoWidth || 1280;
    const h = video.videoHeight || 960;
    const scale = Math.min(1, 1280 / Math.max(w, h));
    canvas.width = Math.round(w * scale);
    canvas.height = Math.round(h * scale);
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL("image/jpeg", 0.85);
    stopStream();
    onCapture(dataUrl);
  }, [onCapture, stopStream]);

  // Start camera
  useEffect(() => {
    let cancelled = false;

    (async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia) {
          throw new Error("unsupported");
        }
        const stream = await navigator.mediaDevices
          .getUserMedia({
            video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 } },
            audio: false,
          })
          .catch(() =>
            navigator.mediaDevices.getUserMedia({ video: true, audio: false })
          );
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => {});
        }
        setReady(true);
      } catch (e) {
        const name = (e as DOMException)?.name;
        setError(
          name === "NotAllowedError"
            ? "scanner.err.denied"
            : name === "NotFoundError"
              ? "scanner.err.notFound"
              : "scanner.err.generic"
        );
      }
    })();

    return () => {
      cancelled = true;
      stopStream();
    };
  }, [stopStream]);

  // Barcode detection loop
  useEffect(() => {
    if (mode !== "barcode" || !ready || error) return;
    const Ctor = (
      window as unknown as {
        BarcodeDetector?: new (o?: { formats?: string[] }) => BarcodeDetectorLike;
      }
    ).BarcodeDetector;
    if (!Ctor) {
      setHint("scanner.hint.unsupported");
      return;
    }
    const detector = new Ctor({
      formats: ["ean_13", "ean_8", "upc_a", "upc_e", "code_128", "code_39", "itf"],
    });
    setHint("scanner.hint.barcode");
    let stopped = false;
    const id = window.setInterval(async () => {
      const video = videoRef.current;
      if (!video || video.readyState < 2 || stopped || capturedRef.current) return;
      try {
        const codes = await detector.detect(video);
        const raw = codes[0]?.rawValue;
        if (raw && /^[0-9]{6,14}$/.test(raw)) {
          stopped = true;
          capturedRef.current = true;
          window.clearInterval(id);
          stopStream();
          onBarcode?.(raw);
        }
      } catch {
        /* ignore frame errors */
      }
    }, 350);
    return () => {
      stopped = true;
      window.clearInterval(id);
    };
  }, [mode, ready, error, onBarcode, stopStream]);

  // Auto-capture loop: wait until the frame is sharp and steady
  useEffect(() => {
    if (mode === "barcode" || !ready || error) return;

    const canvas = document.createElement("canvas");
    canvas.width = SAMPLE_W;
    canvas.height = SAMPLE_H;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (!ctx) return;

    const id = window.setInterval(() => {
      const video = videoRef.current;
      if (!video || video.readyState < 2 || capturedRef.current) return;

      ctx.drawImage(video, 0, 0, SAMPLE_W, SAMPLE_H);
      const { data } = ctx.getImageData(0, 0, SAMPLE_W, SAMPLE_H);
      const luma = new Float32Array(SAMPLE_W * SAMPLE_H);
      let sum = 0;
      for (let i = 0; i < luma.length; i++) {
        const v =
          0.299 * (data[i * 4] ?? 0) +
          0.587 * (data[i * 4 + 1] ?? 0) +
          0.114 * (data[i * 4 + 2] ?? 0);
        luma[i] = v;
        sum += v;
      }
      const mean = sum / luma.length;
      let variance = 0;
      for (let i = 0; i < luma.length; i++) {
        variance += ((luma[i] ?? 0) - mean) ** 2;
      }
      variance /= luma.length;

      const prev = prevRef.current;
      prevRef.current = luma;

      if (variance < SHARPNESS_THRESHOLD) {
        stableRef.current = 0;
        setProgress(0);
        setHint("scanner.hint.closer");
        return;
      }
      if (!prev) return;

      let diff = 0;
      for (let i = 0; i < luma.length; i++)
        diff += Math.abs((luma[i] ?? 0) - (prev[i] ?? 0));
      diff /= luma.length;

      if (diff < MOTION_THRESHOLD) {
        stableRef.current += 1;
        setHint("scanner.hint.hold");
      } else {
        stableRef.current = 0;
        setHint("scanner.hint.label");
      }

      setProgress(Math.min(1, stableRef.current / STABLE_FRAMES));
      if (stableRef.current >= STABLE_FRAMES) {
        window.clearInterval(id);
        capture();
      }
    }, 200);

    return () => window.clearInterval(id);
  }, [mode, ready, error, capture]);

  const handleClose = useCallback(() => {
    stopStream();
    onClose();
  }, [onClose, stopStream]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-ink/95 backdrop-blur-sm">
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2 text-cream">
          <ScanLine className="size-4 text-brand" />
          <span className="text-sm font-bold">{mode === "barcode" ? t("scanner.title.barcode") : t("scanner.title.photo")}</span>
        </div>
        <button
          onClick={handleClose}
          aria-label={t("scanner.close")}
          className="grid size-9 place-items-center rounded-full bg-cream/10 text-cream transition hover:bg-cream/20"
        >
          <X className="size-4" />
        </button>
      </div>

      <div className="relative mx-auto w-full max-w-[414px] flex-1 px-4">
        <div className="relative aspect-[3/4] w-full overflow-hidden rounded-2xl bg-black">
          <video
            ref={videoRef}
            playsInline
            muted
            autoPlay
            className="h-full w-full object-cover"
          />

          {/* Scan frame */}
          <div className="pointer-events-none absolute inset-6 rounded-xl border-2 border-brand/70">
            <span className="absolute -left-0.5 -top-0.5 size-6 rounded-tl-xl border-l-4 border-t-4 border-brand" />
            <span className="absolute -right-0.5 -top-0.5 size-6 rounded-tr-xl border-r-4 border-t-4 border-brand" />
            <span className="absolute -bottom-0.5 -left-0.5 size-6 rounded-bl-xl border-b-4 border-l-4 border-brand" />
            <span className="absolute -bottom-0.5 -right-0.5 size-6 rounded-br-xl border-b-4 border-r-4 border-brand" />
          </div>

          {error && (
            <div className="absolute inset-0 grid place-items-center bg-ink/80 px-6 text-center">
              <div>
                <Camera className="mx-auto size-8 text-cream/60" />
                <p className="mt-3 text-sm text-cream">{t(error)}</p>
                <button
                  onClick={() => window.location.reload()}
                  className="mt-4 inline-flex items-center gap-2 rounded-lg bg-brand px-4 py-2 text-xs font-bold text-brand-foreground"
                >
                  <RefreshCw className="size-3.5" />
                  {t("scanner.retry")}
                </button>
              </div>
            </div>
          )}
        </div>

        {!error && (
          <div className="mt-4">
            <div className={`h-1.5 w-full overflow-hidden rounded-full bg-cream/15 ${mode === "barcode" ? "hidden" : ""}`}>
              <div
                className="h-full rounded-full bg-brand transition-[width] duration-200"
                style={{ width: `${Math.round(progress * 100)}%` }}
              />
            </div>
            <p className="mt-2 text-center text-xs font-medium text-cream/80">
              {ready ? t(hint) : t("scanner.starting")}
            </p>
            <button
              onClick={capture}
              disabled={!ready}
              className="mt-4 w-full rounded-lg bg-cream px-4 py-3 text-sm font-bold text-ink transition disabled:opacity-50"
            >
              {t("scanner.capture")}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
