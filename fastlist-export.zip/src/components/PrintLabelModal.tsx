import { useCallback, useEffect, useState } from "react";
import QRCode from "qrcode";
import { Check, Copy, Printer, X } from "lucide-react";
import { toast } from "sonner";

import { useI18n } from "@/lib/i18n";
import type { ListingData } from "@/lib/listing-types";

type Props = {
  listing: ListingData;
  barcode: string | null;
  onClose: () => void;
};

export function labelText(listing: ListingData, barcode: string | null): string {
  const lines = [
    listing.title,
    listing.price,
    ...listing.benefits.slice(0, 5),
    barcode ? `SKU: ${barcode}` : "",
  ];
  return lines.filter(Boolean).join("\n");
}

export default function PrintLabelModal({ listing, barcode, onClose }: Props) {
  const { t } = useI18n();
  const [qrUrl, setQrUrl] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const qrContent = barcode ?? `${listing.title} — ${listing.price}`;

  useEffect(() => {
    let cancelled = false;
    QRCode.toDataURL(qrContent, { width: 220, margin: 1 })
      .then((url) => {
        if (!cancelled) setQrUrl(url);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [qrContent]);

  // Auto-open the system print dialog once the QR is ready
  useEffect(() => {
    if (!qrUrl) return;
    const timer = setTimeout(() => window.print(), 400);
    return () => clearTimeout(timer);
  }, [qrUrl]);

  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(labelText(listing, barcode));
      setCopied(true);
      toast.success(t("toast.copiedShort"));
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error(t("toast.copyFailed"));
    }
  }, [listing, barcode, t]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-4 backdrop-blur-sm sm:items-center"
      onClick={onClose}
    >
      <div
        className="w-full max-w-[360px] rounded-2xl border border-border bg-card p-4 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-center justify-between">
          <h3 className="font-display text-base font-bold text-ink">
            {t("label.heading")}
          </h3>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-ink/50 transition hover:bg-ink/5"
            aria-label={t("common.close")}
          >
            <X className="size-4" />
          </button>
        </div>

        {/* The label itself — only this prints */}
        <div className="print-label rounded-xl border-2 border-dashed border-ink/20 bg-white p-4 text-center">
          <p className="font-display text-lg font-bold leading-tight text-ink">
            {listing.title}
          </p>
          <p className="mt-1 font-display text-2xl font-bold tracking-tight text-brand">
            {listing.price}
          </p>
          {listing.benefits.length > 0 && (
            <ul className="mt-2 space-y-0.5 text-[12px] leading-snug text-ink/75">
              {listing.benefits.slice(0, 5).map((b) => (
                <li key={b}>{b}</li>
              ))}
            </ul>
          )}
          {qrUrl && (
            <img
              src={qrUrl}
              alt="QR"
              className="mx-auto mt-3 size-24"
            />
          )}
          {barcode && (
            <p className="mt-1 font-mono text-[11px] tracking-widest text-ink/70">
              {barcode}
            </p>
          )}
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2">
          <button
            onClick={() => window.print()}
            className="flex items-center justify-center gap-1.5 rounded-lg bg-brand px-3 py-2.5 text-xs font-bold text-brand-foreground shadow-sm shadow-brand/20 transition hover:bg-brand-deep active:scale-[0.98]"
          >
            <Printer className="size-4" />
            {t("label.print")}
          </button>
          <button
            onClick={() => void handleCopy()}
            className="flex items-center justify-center gap-1.5 rounded-lg border border-brand/40 px-3 py-2.5 text-xs font-bold text-brand transition hover:bg-brand/5 active:scale-[0.98]"
          >
            {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
            {t("label.copy")}
          </button>
        </div>
        <p className="mt-2 text-center text-[11px] text-ink/45">
          {t("label.copyHint")}
        </p>
      </div>
    </div>
  );
}
