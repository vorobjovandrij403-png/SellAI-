import { useMemo, useState } from "react";
import { Check, Languages, Plus, Search, X } from "lucide-react";

import { useI18n, LANGUAGE_BY_CODE, searchLanguages } from "@/lib/i18n";

type Props = {
  /** Language of the primary listing (always included, not removable) */
  primary: string;
  /** Extra output languages */
  selected: string[];
  onChange: (codes: string[]) => void;
};

export default function OutputLanguages({ primary, selected, onChange }: Props) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  const results = useMemo(
    () => searchLanguages(query).filter((l) => l.code !== primary),
    [query, primary]
  );

  const toggle = (code: string) => {
    onChange(
      selected.includes(code)
        ? selected.filter((c) => c !== code)
        : [...selected, code]
    );
  };

  const primaryMeta = LANGUAGE_BY_CODE[primary];

  return (
    <div className="rounded-xl border border-border bg-card p-3">
      <p className="flex items-center gap-2 text-[13px] font-semibold text-ink">
        <Languages className="size-4 text-brand" />
        {t("outputLangs.title")}
      </p>
      <p className="mt-1 text-[11px] leading-snug text-ink/50">
        {t("outputLangs.hint")}
      </p>

      <div className="mt-2.5 flex flex-wrap gap-1.5">
        <span className="flex items-center gap-1 rounded-full bg-brand px-2.5 py-1 text-[11px] font-semibold text-brand-foreground">
          <Check className="size-3" />
          {primaryMeta?.flag ?? "🌐"} {primaryMeta?.native ?? primary}
        </span>
        {selected.map((code) => {
          const meta = LANGUAGE_BY_CODE[code];
          return (
            <button
              key={code}
              onClick={() => toggle(code)}
              className="flex items-center gap-1 rounded-full bg-brand/10 px-2.5 py-1 text-[11px] font-semibold text-brand transition hover:bg-brand/20"
            >
              {meta?.flag ?? "🌐"} {meta?.native ?? code}
              <X className="size-3" />
            </button>
          );
        })}
        <button
          onClick={() => {
            setQuery("");
            setOpen(true);
          }}
          className="flex items-center gap-1 rounded-full border border-dashed border-brand/40 px-2.5 py-1 text-[11px] font-semibold text-brand transition hover:bg-brand/5"
        >
          <Plus className="size-3" />
          {t("outputLangs.add")}
        </button>
      </div>

      {open && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/50 backdrop-blur-sm sm:items-center sm:p-4">
          <div className="flex h-[85vh] w-full max-w-[414px] flex-col rounded-t-2xl bg-card shadow-xl sm:h-[70vh] sm:rounded-2xl">
            <div className="flex items-center justify-between gap-3 border-b border-border p-4">
              <h2 className="font-display text-base font-bold text-ink">
                {t("outputLangs.title")}
              </h2>
              <button
                onClick={() => setOpen(false)}
                aria-label={t("common.close")}
                className="grid size-8 shrink-0 place-items-center rounded-full bg-sand text-ink/60 transition hover:bg-muted"
              >
                <X className="size-4" />
              </button>
            </div>

            <div className="p-3">
              <div className="flex items-center gap-2 rounded-lg border border-input bg-card px-3 py-2.5">
                <Search className="size-4 shrink-0 text-ink/40" />
                <input
                  autoFocus
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder={t("lang.search")}
                  className="w-full bg-transparent text-sm text-ink outline-none placeholder:text-ink/40"
                />
              </div>
              <p className="mt-2 px-1 text-[11px] text-ink/50">
                {t("outputLangs.selected", { count: selected.length })}
              </p>
            </div>

            <div className="min-h-0 flex-1 overflow-y-auto px-3 pb-4">
              {results.length === 0 ? (
                <p className="px-2 py-6 text-center text-sm text-ink/50">
                  {t("lang.noResults")}
                </p>
              ) : (
                <ul className="space-y-1">
                  {results.map((item) => {
                    const active = selected.includes(item.code);
                    return (
                      <li key={item.code}>
                        <button
                          onClick={() => toggle(item.code)}
                          className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left transition ${
                            active
                              ? "bg-brand/10 text-brand"
                              : "text-ink/80 hover:bg-sand"
                          }`}
                        >
                          <span
                            className={`grid size-4 shrink-0 place-items-center rounded border ${
                              active
                                ? "border-brand bg-brand text-brand-foreground"
                                : "border-input"
                            }`}
                          >
                            {active && <Check className="size-3" />}
                          </span>
                          <span className="w-6 shrink-0 text-lg leading-none">
                            {item.flag ?? "🌐"}
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-sm font-semibold">
                              {item.native}
                            </span>
                            <span className="block truncate text-[11px] text-ink/45">
                              {item.english}
                            </span>
                          </span>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>

            <div className="border-t border-border p-3">
              <button
                onClick={() => setOpen(false)}
                className="w-full rounded-lg bg-brand py-2.5 text-sm font-bold text-brand-foreground transition hover:bg-brand-deep"
              >
                {t("common.close")}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
