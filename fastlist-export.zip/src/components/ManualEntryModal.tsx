import { useEffect, useState } from "react";
import { X, Save, Sparkles } from "lucide-react";
import { useI18n } from "@/lib/i18n";

export type ManualProduct = {
  name: string;
  description: string;
  price: string;
  category: string;
  specs: string;
};

const STORAGE_KEY = "fastlist.manualDraft";
const empty: ManualProduct = { name: "", description: "", price: "", category: "", specs: "" };

type Props = {
  onClose: () => void;
  onSave: (p: ManualProduct) => void;
  onGenerate: (p: ManualProduct) => void;
};

export default function ManualEntryModal({ onClose, onSave, onGenerate }: Props) {
  const { t } = useI18n();
  const [form, setForm] = useState<ManualProduct>(empty);
  const [error, setError] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setForm({ ...empty, ...JSON.parse(raw) });
    } catch {
      /* ignore */
    }
  }, []);

  const set = (k: keyof ManualProduct) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = (fn: (p: ManualProduct) => void) => {
    if (!form.name.trim()) {
      setError(true);
      return;
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(form));
    fn(form);
  };

  const field = "w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm text-ink outline-none focus:border-brand focus:ring-2 focus:ring-brand/20";
  const label = "mb-1 block text-xs font-semibold text-ink/70";

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/50 sm:items-center" onClick={onClose}>
      <div
        className="max-h-[92vh] w-full max-w-md overflow-y-auto rounded-t-2xl bg-card p-5 shadow-xl sm:rounded-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-bold text-ink">{t("manual.title")}</h2>
          <button onClick={onClose} aria-label={t("manual.close")} className="rounded-md p-1 text-ink/50 hover:text-ink">
            <X className="size-5" />
          </button>
        </div>
        <div className="space-y-3">
          <div>
            <label className={label}>{t("manual.name")} *</label>
            <input className={field} value={form.name} onChange={(e) => { set("name")(e); setError(false); }} placeholder={t("manual.namePh")} />
            {error && <p className="mt-1 text-xs text-destructive">{t("manual.nameRequired")}</p>}
          </div>
          <div>
            <label className={label}>{t("manual.description")}</label>
            <textarea className={field} rows={3} value={form.description} onChange={set("description")} placeholder={t("manual.descriptionPh")} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={label}>{t("manual.price")}</label>
              <input className={field} value={form.price} onChange={set("price")} placeholder="500 грн" />
            </div>
            <div>
              <label className={label}>{t("manual.category")}</label>
              <input className={field} value={form.category} onChange={set("category")} placeholder={t("manual.categoryPh")} />
            </div>
          </div>
          <div>
            <label className={label}>{t("manual.specs")}</label>
            <textarea className={field} rows={4} value={form.specs} onChange={set("specs")} placeholder={t("manual.specsPh")} />
          </div>
        </div>
        <div className="mt-5 grid grid-cols-2 gap-2">
          <button onClick={() => submit(onSave)} className="flex items-center justify-center gap-2 rounded-lg border border-brand/30 bg-brand/5 px-3 py-3 text-sm font-semibold text-brand hover:bg-brand/10">
            <Save className="size-4" /> {t("manual.save")}
          </button>
          <button onClick={() => submit(onGenerate)} className="flex items-center justify-center gap-2 rounded-lg bg-brand px-3 py-3 text-sm font-bold text-brand-foreground hover:bg-brand-deep">
            <Sparkles className="size-4" /> {t("manual.generate")}
          </button>
        </div>
      </div>
    </div>
  );
}
