import { Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { cancelSubscription, getMyBilling } from "@/lib/billing.functions";
import { useAuth } from "@/hooks/use-auth";
import { useI18n } from "@/lib/i18n";

export default function AccountBar() {
  const { t, language } = useI18n();
  const { user, ready } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const fetchBilling = useServerFn(getMyBilling);
  const cancel = useServerFn(cancelSubscription);
  const { data } = useQuery({
    queryKey: ["billing", user?.id],
    queryFn: () => fetchBilling(),
    enabled: !!user,
  });

  if (!ready) return null;
  if (!user) {
    return (
      <Link to="/auth" className="rounded-lg border border-border bg-card px-3 py-1.5 text-xs font-semibold text-ink">
        {t("account.signIn")}
      </Link>
    );
  }

  const fmt = (d: string | null) => (d ? new Date(d).toLocaleDateString(language) : "");

  return (
    <div className="mb-4 rounded-xl border border-border bg-card p-3 text-xs">
      <div className="flex items-center justify-between gap-2">
        <span className="truncate font-semibold text-ink">{user.email}</span>
        <button
          onClick={async () => {
            await qc.cancelQueries();
            qc.clear();
            await supabase.auth.signOut();
            navigate({ to: "/auth", replace: true });
          }}
          className="shrink-0 text-ink/50 hover:text-ink"
        >
          {t("account.signOut")}
        </button>
      </div>
      {data && (
        <div className="mt-2 space-y-0.5 text-ink/60">
          <p>
            {t("account.plan", { plan: (data.plan ?? "Free").toUpperCase() })}
            {data.status === "trialing" && ` · ${t("account.trialUntil", { date: fmt(data.trialEndsAt) })}`}
            {(data.status === "active" || data.status === "canceled") &&
              ` · ${t("account.until", { date: fmt(data.periodEnd) })}`}
          </p>
          <p>{t("account.usage", { used: data.used, limit: data.limit })}</p>
          {(data.status === "trialing" || data.status === "active") && (
            <button
              onClick={async () => {
                await cancel();
                toast.success(t("account.canceled"));
                qc.invalidateQueries({ queryKey: ["billing"] });
              }}
              className="mt-1 font-semibold text-destructive"
            >
              {t("account.cancel")}
            </button>
          )}
        </div>
      )}
    </div>
  );
}
