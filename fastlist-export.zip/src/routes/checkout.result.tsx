import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { CheckCircle2, Loader2, XCircle } from "lucide-react";
import { z } from "zod";
import { getOrderStatus } from "@/lib/billing.functions";
import { useAuth } from "@/hooks/use-auth";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/checkout/result")({
  validateSearch: z.object({ order: z.string().optional().default("") }),
  head: () => ({
    meta: [
      { title: "Payment status — FastList" },
      { name: "description", content: "Status of your FastList free trial activation." },
      { property: "og:title", content: "Payment status — FastList" },
      { property: "og:description", content: "Status of your FastList free trial activation." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ResultPage,
});

function ResultPage() {
  const { order } = Route.useSearch();
  const { t, language } = useI18n();
  const { user, ready } = useAuth();
  const fetchStatus = useServerFn(getOrderStatus);
  const { data } = useQuery({
    queryKey: ["order", order],
    queryFn: () => fetchStatus({ data: { order } }),
    enabled: ready && !!user && !!order,
    refetchInterval: (q) => (q.state.data?.status && q.state.data.status !== "pending" ? false : 2000),
  });

  const status = data?.status ?? "pending";
  const ok = status === "trialing" || status === "active";
  const fail = status === "failed";
  const date = data?.trial_ends_at
    ? new Date(data.trial_ends_at).toLocaleDateString(language)
    : "";

  return (
    <div className="min-h-screen bg-background px-4 pt-16 text-ink">
      <div className="mx-auto max-w-[414px] rounded-2xl border border-border bg-card p-6 text-center shadow-sm">
        {ok ? (
          <CheckCircle2 className="mx-auto size-12 text-brand" />
        ) : fail ? (
          <XCircle className="mx-auto size-12 text-destructive" />
        ) : (
          <Loader2 className="mx-auto size-12 animate-spin text-brand" />
        )}
        <h1 className="mt-4 text-lg font-bold">
          {t(ok ? "result.title.ok" : fail ? "result.title.fail" : "result.title.pending")}
        </h1>
        <p className="mt-2 text-sm text-ink/60">
          {ok
            ? t("result.text.ok", { plan: (data?.plan ?? "").toUpperCase(), date })
            : t(fail ? "result.text.fail" : "result.text.pending")}
        </p>
        <Link to="/" className="mt-6 inline-block rounded-lg bg-brand px-5 py-2.5 text-sm font-bold text-brand-foreground">
          {t("result.back")}
        </Link>
      </div>
    </div>
  );
}
