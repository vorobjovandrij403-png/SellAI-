import { createFileRoute } from "@tanstack/react-router";
import { authenticateCronRequest } from "@/integrations/supabase/cron-auth";

// Daily job: charges subscriptions whose trial or month has ended, using the saved card token.
export const Route = createFileRoute("/api/public/billing/renew")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const denied = await authenticateCronRequest(request);
        if (denied) return denied;

        const { wfpConfig, wfpSign, addDays, PLANS, CURRENCY } = await import(
          "@/lib/wayforpay.server"
        );
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const cfg = wfpConfig();
        const nowIso = new Date().toISOString();

        const { data: due } = await supabaseAdmin
          .from("subscriptions")
          .select("id,user_id,plan,status,rec_token,order_reference")
          .in("status", ["trialing", "active"])
          .lte("current_period_end", nowIso)
          .not("rec_token", "is", null)
          .limit(50);

        let charged = 0;
        for (const sub of due ?? []) {
          const plan = PLANS[sub.plan as keyof typeof PLANS];
          if (!plan) continue;
          const orderReference = `${sub.order_reference}-R${Date.now()}`;
          const orderDate = Math.floor(Date.now() / 1000);
          const amount = plan.amount.toFixed(2);
          const { data: profile } = await supabaseAdmin
            .from("profiles")
            .select("email,full_name,phone")
            .eq("id", sub.user_id)
            .maybeSingle();

          const body = {
            transactionType: "CHARGE",
            merchantAccount: cfg.account,
            merchantAuthType: "SimpleSignature",
            merchantDomainName: cfg.domain,
            apiVersion: 1,
            orderReference,
            orderDate,
            amount,
            currency: CURRENCY,
            recToken: sub.rec_token,
            productName: [plan.name],
            productPrice: [amount],
            productCount: [1],
            clientFirstName: profile?.full_name?.split(" ")[0] ?? "Client",
            clientLastName: profile?.full_name?.split(" ").slice(1).join(" ") || "FastList",
            clientEmail: profile?.email ?? "",
            clientPhone: profile?.phone ?? "",
            clientCountry: "UKR",
            merchantSignature: wfpSign(
              [cfg.account, cfg.domain, orderReference, orderDate, amount, CURRENCY, plan.name, 1, amount],
              cfg.secret
            ),
          };

          let approved = false;
          try {
            const res = await fetch("https://api.wayforpay.com/api", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(body),
            });
            const json = (await res.json()) as { transactionStatus?: string };
            approved = json.transactionStatus === "Approved";
          } catch (e) {
            console.error("WayForPay charge failed", e);
          }

          await supabaseAdmin
            .from("subscriptions")
            .update(
              approved
                ? {
                    status: "active",
                    current_period_end: addDays(new Date(), 30).toISOString(),
                    updated_at: nowIso,
                  }
                : { status: "failed", updated_at: nowIso }
            )
            .eq("id", sub.id);
          if (approved) charged++;
        }

        // Canceled subscriptions simply expire at current_period_end (no charge).
        return Response.json({ checked: due?.length ?? 0, charged });
      },
    },
  },
});
