import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const payloadSchema = z.object({
  merchantAccount: z.string(),
  orderReference: z.string().max(120),
  amount: z.union([z.number(), z.string()]),
  currency: z.string(),
  authCode: z.union([z.string(), z.number()]).optional().default(""),
  cardPan: z.string().optional().default(""),
  transactionStatus: z.string(),
  reasonCode: z.union([z.string(), z.number()]).optional().default(""),
  recToken: z.string().optional(),
  merchantSignature: z.string(),
});

function parseBody(raw: string): unknown {
  try {
    return JSON.parse(raw);
  } catch {
    // Some WayForPay callbacks arrive form-encoded with the JSON as the only key.
    const params = new URLSearchParams(raw);
    const firstKey = [...params.keys()][0];
    return firstKey ? JSON.parse(firstKey) : {};
  }
}

export const Route = createFileRoute("/api/public/wayforpay/callback")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { wfpConfig, wfpSign, addDays, TRIAL_DAYS } = await import(
          "@/lib/wayforpay.server"
        );
        const cfg = wfpConfig();
        let p: z.infer<typeof payloadSchema>;
        try {
          p = payloadSchema.parse(parseBody(await request.text()));
        } catch {
          return new Response("Bad request", { status: 400 });
        }

        const expected = wfpSign(
          [
            p.merchantAccount,
            p.orderReference,
            p.amount,
            p.currency,
            p.authCode,
            p.cardPan,
            p.transactionStatus,
            p.reasonCode,
          ],
          cfg.secret
        );
        if (expected !== p.merchantSignature || p.merchantAccount !== cfg.account) {
          return new Response("Invalid signature", { status: 401 });
        }

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data: sub } = await supabaseAdmin
          .from("subscriptions")
          .select("id,status")
          .eq("order_reference", p.orderReference)
          .maybeSingle();

        if (sub && sub.status === "pending") {
          if (p.transactionStatus === "Approved" && p.recToken) {
            const trialEnd = addDays(new Date(), TRIAL_DAYS).toISOString();
            await supabaseAdmin
              .from("subscriptions")
              .update({
                status: "trialing",
                rec_token: p.recToken,
                card_pan: p.cardPan,
                trial_ends_at: trialEnd,
                current_period_end: trialEnd,
                updated_at: new Date().toISOString(),
              })
              .eq("id", sub.id);
          } else if (["Declined", "Expired", "Refunded"].includes(p.transactionStatus)) {
            await supabaseAdmin
              .from("subscriptions")
              .update({ status: "failed", updated_at: new Date().toISOString() })
              .eq("id", sub.id);
          }
        }

        const time = Math.floor(Date.now() / 1000);
        return Response.json({
          orderReference: p.orderReference,
          status: "accept",
          time,
          signature: wfpSign([p.orderReference, "accept", time], cfg.secret),
        });
      },
    },
  },
});
