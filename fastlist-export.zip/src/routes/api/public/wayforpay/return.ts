import { createFileRoute } from "@tanstack/react-router";

// WayForPay sends the shopper back with a POST; turn it into a normal page visit.
function redirectToResult(request: Request) {
  const url = new URL(request.url);
  const order = url.searchParams.get("order") ?? "";
  const target = `${url.origin}/checkout/result?order=${encodeURIComponent(order)}`;
  return new Response(null, { status: 303, headers: { Location: target } });
}

export const Route = createFileRoute("/api/public/wayforpay/return")({
  server: {
    handlers: {
      POST: async ({ request }) => redirectToResult(request),
      GET: async ({ request }) => redirectToResult(request),
    },
  },
});
