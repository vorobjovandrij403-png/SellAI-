import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — FastList" },
      { name: "description", content: "Sign in to FastList to manage your plan and free trial." },
      { property: "og:title", content: "Sign in — FastList" },
      { property: "og:description", content: "Sign in to FastList to manage your plan and free trial." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

const inputCls =
  "mt-1 w-full rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-ink outline-none focus:border-brand";

function AuthPage() {
  const { t } = useI18n();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "in") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: "/", replace: true });
      } else {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
        if (data.session) navigate({ to: "/", replace: true });
        else toast.success(t("auth.checkEmail"));
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Error");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-background px-4 pt-10 text-ink">
      <div className="mx-auto max-w-[414px] rounded-2xl border border-border bg-card p-5 shadow-sm">
        <Link to="/" className="font-display text-xl font-extrabold">
          Fast<span className="text-brand">List</span>
        </Link>
        <h1 className="mt-3 text-lg font-bold">{t(mode === "in" ? "auth.title.in" : "auth.title.up")}</h1>
        <form onSubmit={submit} className="mt-4 space-y-3">
          <label className="block text-[11px] font-semibold uppercase tracking-wider text-ink/50">
            Email
            <input type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className={inputCls} />
          </label>
          <label className="block text-[11px] font-semibold uppercase tracking-wider text-ink/50">
            {t("auth.password")}
            <input type="password" required minLength={6} autoComplete={mode === "in" ? "current-password" : "new-password"} value={password} onChange={(e) => setPassword(e.target.value)} className={inputCls} />
          </label>
          <button type="submit" disabled={busy} className="w-full rounded-lg bg-brand py-3 text-sm font-bold text-brand-foreground transition hover:bg-brand-deep disabled:opacity-70">
            {t(mode === "in" ? "auth.submit.in" : "auth.submit.up")}
          </button>
        </form>
        <button onClick={() => setMode(mode === "in" ? "up" : "in")} className="mt-4 w-full text-center text-xs font-semibold text-brand">
          {t(mode === "in" ? "auth.switch.up" : "auth.switch.in")}
        </button>
      </div>
    </div>
  );
}
