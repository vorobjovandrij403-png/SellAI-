import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState, useRef, useCallback, lazy, Suspense, useMemo } from "react";
import { toast } from "sonner";
import { Copy, Upload, Sparkles, Check, ScanLine, Barcode, PencilLine, Printer } from "lucide-react";
import ManualEntryModal, { type ManualProduct } from "@/components/ManualEntryModal";
import { generateListingFromManual } from "@/lib/manual-listing.functions";
import { generateListingFromImage } from "@/lib/generate-listing.functions";
import { generateListingFromBarcode } from "@/lib/barcode-lookup.functions";
import type { CheckoutPlan } from "@/components/CheckoutModal";
import type { ListingData, Platform } from "@/lib/listing-types";
import { useI18n, LANGUAGE_BY_CODE } from "@/lib/i18n";
import LanguageSwitcher from "@/components/LanguageSwitcher";
import OutputLanguages from "@/components/OutputLanguages";
import AccountBar from "@/components/AccountBar";
import { useAuth } from "@/hooks/use-auth";
import copperTumbler from "@/assets/copper-tumbler.jpg";

const CameraScanner = lazy(() => import("@/components/CameraScanner"));
const CheckoutModal = lazy(() => import("@/components/CheckoutModal"));
const PrintLabelModal = lazy(() => import("@/components/PrintLabelModal"));

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FastList — AI listings from a product photo" },
      {
        name: "description",
        content:
          "Upload a product photo and get a ready-to-post listing in seconds: title, description, tags, price and social posts — in 100+ languages.",
      },
      {
        property: "og:title",
        content: "FastList — AI listings from a product photo",
      },
      {
        property: "og:description",
        content:
          "Photo in, ready listing out — in your language and 100+ more.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const platformLabels: Record<Platform, string> = {
  olx: "OLX",
  prom: "Prom",
  instagram: "Instagram",
};

const demoUk: ListingData = {
  title: "Ручний мідний келих TALUKA, 250 мл",
  shortDescription:
    "Келих ручної роботи з натуральної міді, поліруваний до теплого блиску. Місткість 250 мл — ідеальний для води, соку чи коктейлю.",
  fullDescription:
    "Стильний мідний келих TALUKA об'ємом 250 мл виготовлений вручну з високоякісної натуральної міді. Полірована поверхня дає теплий відблиск та унікальний малюнок ковальських міток. Мідь довше зберігає прохолоду напою, а її антибактеріальні властивості роблять келих безпечним для щоденного використання.",
  benefits: [
    "Натуральна мідь, ручна робота",
    "Кожен келих — унікальний малюнок",
    "Зберігає прохолоду напою довше",
    "Антибактеріальні властивості міді",
    "Гарантія якості 2 роки",
  ],
  seoTags: ["мідь", "ручна робота", "келих", "посуд", "250 мл", "TALUKA", "handmade"],
  olxTags: ["посуд", "мідний келих", "декор", "ручна робота", "250 мл", "TALUKA", "київ"],
  promTags: ["посуд", "мідний келих", "декор", "ручна робота", "250 мл", "TALUKA", "handmade"],
  price: "450 – 550 грн",
  facebook:
    "Продаю ручний мідний келих TALUKA, 250 мл. Натуральна мідь, приємний теплий блиск. Доставка по всій Україні.",
  instagram:
    "Вечірній настрій у формі одного келиха 🍂 Тепла мідь, ручна робота, унікальний відтінок.\n\n#мідь #ручнаробота #handmade #келих #посуд #TALUKA",
  platformPosts: {
    olx: "Продаю ручний мідний келих TALUKA, 250 мл. Натуральна мідь, полірована до теплого блиску. Ціна: 450–550 грн. Доставка по всій Україні.",
    prom: "Мідний келих TALUKA 250 мл — ручна робота з натуральної міді. Опт та роздріб. Гарантія 2 роки. Ціна: 450–550 грн.",
    instagram:
      "Вечірній настрій у формі одного келиха 🍂 Тепла мідь, ручна робота, унікальний відтінок.\n\n#мідь #ручнаробота #handmade #келих #посуд #TALUKA",
  },
  variants: [
    {
      code: "en",
      label: "English",
      title: "Handcrafted copper tumbler TALUKA, 250 ml",
      shortDescription:
        "Hand-hammered natural copper tumbler polished to a warm glow. 250 ml — perfect for water, juice or cocktails.",
      fullDescription:
        "A hand-made TALUKA copper tumbler crafted from high-grade natural copper. Every piece carries its own hammer pattern, keeps drinks cooler for longer and is naturally antibacterial.",
      post: "Handcrafted copper tumbler TALUKA, 250 ml. Natural copper, warm polished finish, one-of-a-kind hammer pattern. Worldwide shipping available.",
    },
  ],
};

const demoEn: ListingData = {
  title: "Handcrafted copper tumbler TALUKA, 250 ml",
  shortDescription:
    "Hand-hammered natural copper tumbler polished to a warm glow. 250 ml — perfect for water, juice or cocktails.",
  fullDescription:
    "A hand-made TALUKA copper tumbler crafted from high-grade natural copper. The polished surface gives a warm shine and a unique hammer pattern. Copper keeps drinks cool longer and is naturally antibacterial, which makes the tumbler both practical and safe for daily use.",
  benefits: [
    "Natural copper, fully handmade",
    "Every piece has a unique pattern",
    "Keeps drinks cool for longer",
    "Naturally antibacterial material",
    "2-year quality guarantee",
  ],
  seoTags: ["copper", "handmade", "tumbler", "kitchenware", "250 ml", "TALUKA", "gift"],
  olxTags: ["kitchenware", "copper tumbler", "decor", "handmade", "250 ml", "TALUKA", "gift"],
  promTags: ["kitchenware", "copper tumbler", "decor", "handmade", "250 ml", "TALUKA", "wholesale"],
  price: "€12 – €15",
  facebook:
    "Selling a handcrafted TALUKA copper tumbler, 250 ml. Natural copper with a warm polished finish. Shipping available.",
  instagram:
    "Evening mood in one tumbler 🍂 Warm copper, handmade, one-of-a-kind finish.\n\n#copper #handmade #tumbler #kitchenware #TALUKA",
  platformPosts: {
    olx: "Handcrafted copper tumbler TALUKA, 250 ml. Natural copper, polished to a warm glow. Price: €12–15. Shipping available.",
    prom: "TALUKA copper tumbler 250 ml — handmade from natural copper. Wholesale and retail. 2-year guarantee. Price: €12–15.",
    instagram:
      "Evening mood in one tumbler 🍂 Warm copper, handmade, one-of-a-kind finish.\n\n#copper #handmade #tumbler #kitchenware #TALUKA",
  },
  variants: [],
};

function CopyButton({ text, label }: { text: string; label?: string }) {
  const { t } = useI18n();
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast.success(
        label ? t("toast.copied", { label }) : t("toast.copiedShort")
      );
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error(t("toast.copyFailed"));
    }
  }, [text, label, t]);

  return (
    <button
      onClick={handleCopy}
      className="flex shrink-0 items-center gap-1 rounded-lg bg-brand/8 px-2.5 py-1.5 text-[11px] font-semibold text-brand transition-colors hover:bg-brand/15 active:scale-95"
      aria-label={t("common.copyAria", { label: label ?? "" })}
    >
      {copied ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
      <span>{t("common.copy")}</span>
    </button>
  );
}

function CopyAllButton({ text }: { text: string }) {
  const { t } = useI18n();
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast.success(t("toast.copiedAll"));
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error(t("toast.copyFailed"));
    }
  }, [text, t]);

  return (
    <button
      onClick={handleCopy}
      className="flex shrink-0 items-center gap-1.5 rounded-lg bg-brand px-3 py-1.5 text-[11px] font-bold text-brand-foreground shadow-sm shadow-brand/20 transition hover:bg-brand-deep active:scale-95"
    >
      {copied ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
      <span>{t("results.copyAll")}</span>
    </button>
  );
}

function ResultCard({
  title,
  children,
  copyText,
  copyLabel,
  delay = 0,
}: {
  title: string;
  children: React.ReactNode;
  copyText: string;
  copyLabel?: string;
  delay?: number;
}) {
  return (
    <div
      className="animate-result-rise rounded-xl border border-border bg-card p-4 shadow-sm"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <h3 className="text-[11px] font-semibold uppercase tracking-wider text-ink/45">
            {title}
          </h3>
          <div className="mt-2">{children}</div>
        </div>
        <CopyButton text={copyText} label={copyLabel ?? title} />
      </div>
    </div>
  );
}

type Tariff = {
  id: string;
  name: string;
  price: string;
  period: string;
  description: string;
  features: string[];
  trialDays: number;
  cta: string;
  highlighted: boolean;
  badge?: string;
};

function TariffCard({
  tariff,
  onSelect,
}: {
  tariff: Tariff;
  onSelect: () => void;
}) {
  return (
    <div
      className={`rounded-xl p-4 ${
        tariff.highlighted
          ? "bg-brand text-brand-foreground shadow-lg shadow-brand/25"
          : "border border-border bg-card"
      }`}
    >
      <div className="flex items-center justify-between">
        <p className="font-display text-base font-bold">{tariff.name}</p>
        {tariff.badge && (
          <span
            className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${
              tariff.highlighted
                ? "bg-cream/20 text-brand-foreground"
                : "bg-brand/10 text-brand"
            }`}
          >
            {tariff.badge}
          </span>
        )}
      </div>
      <p className="mt-2 font-display text-2xl font-bold tracking-tight">
        {tariff.price}
        {tariff.period && (
          <span
            className={`text-sm font-sans font-medium ${
              tariff.highlighted ? "text-brand-foreground/70" : "text-ink/60"
            }`}
          >
            {tariff.period}
          </span>
        )}
      </p>
      <p
        className={`mt-0.5 text-xs ${
          tariff.highlighted ? "text-brand-foreground/80" : "text-ink/60"
        }`}
      >
        {tariff.description}
      </p>
      <ul className="mt-3 space-y-1.5">
        {tariff.features.map((feature) => (
          <li key={feature} className="flex items-start gap-2 text-xs">
            <span
              className={`mt-1 size-1.5 shrink-0 rounded-full ${
                tariff.highlighted ? "bg-cream" : "bg-brand"
              }`}
            />
            <span
              className={
                tariff.highlighted ? "text-brand-foreground/90" : "text-ink/80"
              }
            >
              {feature}
            </span>
          </li>
        ))}
      </ul>
      <button
        onClick={onSelect}
        className={`mt-4 w-full rounded-lg py-2.5 text-xs font-bold transition-transform active:scale-[0.98] ${
          tariff.highlighted
            ? "bg-cream text-brand-deep"
            : "border border-brand/40 text-brand hover:bg-brand/5"
        }`}
      >
        {tariff.cta}
      </button>
    </div>
  );
}

function Index() {
  const { language, t } = useI18n();

  const [previewUrl, setPreviewUrl] = useState<string | null>(copperTumbler);
  const [imageDataUrl, setImageDataUrl] = useState<string | null>(null);
  const [listing, setListing] = useState<ListingData | null>(null);
  const [hasResults, setHasResults] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [scannerOpen, setScannerOpen] = useState(false);
  const [scanMode, setScanMode] = useState<"photo" | "barcode">("photo");
  const [checkoutPlan, setCheckoutPlan] = useState<CheckoutPlan | null>(null);
  const [barcodeInfo, setBarcodeInfo] = useState<string | null>(null);
  const [lastBarcode, setLastBarcode] = useState<string | null>(null);
  const [labelOpen, setLabelOpen] = useState(false);
  const [platform, setPlatform] = useState<Platform>("olx");
  const [extraLanguages, setExtraLanguages] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const generate = useServerFn(generateListingFromImage);
  const generateByBarcode = useServerFn(generateListingFromBarcode);
  const generateManual = useServerFn(generateListingFromManual);
  const [manualOpen, setManualOpen] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();

  const demo = language.startsWith("uk") ? demoUk : demoEn;
  const current = listing ?? demo;

  const tariffs = useMemo<Tariff[]>(
    () => [
      {
        id: "free",
        name: "Free",
        price: "€0",
        period: "",
        description: t("pricing.freeDesc"),
        features: [
          t("feature.listings", { count: 3 }),
          t("feature.basicTranslations"),
        ],
        trialDays: 0,
        cta: t("pricing.freeCta"),
        highlighted: false,
      },
      {
        id: "start",
        name: "START",
        price: "€4.99",
        period: t("pricing.perMonth"),
        description: t("pricing.trialDesc", { count: 30 }),
        features: [
          t("feature.listings", { count: 30 }),
          t("feature.seo"),
          t("feature.social"),
        ],
        trialDays: 10,
        cta: t("pricing.trialCta"),
        highlighted: false,
        badge: t("pricing.trialBadge"),
      },
      {
        id: "pro",
        name: "PRO",
        price: "€9.99",
        period: t("pricing.perMonth"),
        description: t("pricing.trialDesc", { count: 100 }),
        features: [
          t("feature.listings", { count: 100 }),
          t("feature.allLanguages"),
          t("feature.priority"),
        ],
        trialDays: 10,
        cta: t("pricing.trialCta"),
        highlighted: true,
        badge: t("pricing.trialBadge"),
      },
      {
        id: "business",
        name: "BUSINESS",
        price: "€19.99",
        period: t("pricing.perMonth"),
        description: t("pricing.trialDesc", { count: 500 }),
        features: [
          t("feature.listings", { count: 500 }),
          t("feature.team"),
          t("feature.api"),
        ],
        trialDays: 10,
        cta: t("pricing.trialCta"),
        highlighted: false,
        badge: t("pricing.trialBadge"),
      },
    ],
    [t]
  );

  const runGeneration = useCallback(
    async (dataUrl: string) => {
      setIsGenerating(true);
      setHasResults(false);
      try {
        const result = await generate({
          data: { imageDataUrl: dataUrl, language, extraLanguages },
        });
        setListing(result);
        setHasResults(true);
        toast.success(t("toast.ready"));
      } catch (err) {
        const msg = err instanceof Error ? err.message : "";
        toast.error(
          msg.includes("LIMIT_REACHED")
            ? t("toast.limitReached")
            : msg || t("toast.generateFailed")
        );
      } finally {
        setIsGenerating(false);
      }
    },
    [generate, language, extraLanguages, t]
  );

  const handleFileChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      if (!file.type.startsWith("image/")) {
        toast.error(t("toast.imageOnly"));
        return;
      }

      const url = URL.createObjectURL(file);
      if (previewUrl && previewUrl !== copperTumbler) {
        URL.revokeObjectURL(previewUrl);
      }
      setPreviewUrl(url);
      setHasResults(false);

      const reader = new FileReader();
      reader.onload = () => setImageDataUrl(String(reader.result));
      reader.readAsDataURL(file);

      toast.success(t("toast.photoUploaded"));
    },
    [previewUrl, t]
  );

  const handleUploadClick = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  const handleScanCapture = useCallback(
    (dataUrl: string) => {
      setScannerOpen(false);
      if (previewUrl && previewUrl !== copperTumbler) {
        URL.revokeObjectURL(previewUrl);
      }
      setPreviewUrl(dataUrl);
      setImageDataUrl(dataUrl);
      toast.success(t("toast.captured"));
      void runGeneration(dataUrl);
    },
    [previewUrl, runGeneration, t]
  );

  const runBarcodeGeneration = useCallback(
    async (barcode: string) => {
      setIsGenerating(true);
      setHasResults(false);
      setBarcodeInfo(t("barcode.searching", { code: barcode }));
      try {
        const result = await generateByBarcode({
          data: { barcode, language, extraLanguages },
        });
        setListing(result.listing);
        setHasResults(true);
        setBarcodeInfo(
          `${t("barcode.source", { code: barcode, source: result.source })}${
            result.productName ? ` · ${result.productName}` : ""
          }`
        );
        toast.success(t("toast.productFound"));
      } catch (err) {
        setBarcodeInfo(null);
        const msg = err instanceof Error ? err.message : "";
        toast.error(
          msg.includes("LIMIT_REACHED")
            ? t("toast.limitReached")
            : msg || t("toast.productFailed")
        );
      } finally {
        setIsGenerating(false);
      }
    },
    [generateByBarcode, language, extraLanguages, t]
  );

  const handleBarcode = useCallback(
    (code: string) => {
      setScannerOpen(false);
      setLastBarcode(code);
      void runBarcodeGeneration(code);
    },
    [runBarcodeGeneration]
  );

  const handleManualSave = useCallback(
    (p: ManualProduct) => {
      const specs = p.specs.split("\n").map((s) => s.trim()).filter(Boolean);
      const tags = p.category ? [p.category] : [];
      const text = [p.name, p.description, specs.join("\n"), p.price].filter(Boolean).join("\n\n");
      setListing({
        title: p.name,
        shortDescription: p.description.split(/(?<=[.!?])\s/)[0] ?? p.description,
        fullDescription: [p.description, specs.join("\n")].filter(Boolean).join("\n\n"),
        benefits: specs,
        seoTags: tags,
        olxTags: tags,
        promTags: tags,
        price: p.price,
        facebook: text,
        instagram: text,
        platformPosts: { olx: text, prom: text, instagram: text },
        variants: [],
      });
      setHasResults(true);
      setManualOpen(false);
      toast.success(t("manual.saved"));
    },
    [t]
  );

  const handleManualGenerate = useCallback(
    async (p: ManualProduct) => {
      setManualOpen(false);
      setIsGenerating(true);
      setHasResults(false);
      try {
        const result = await generateManual({ data: { ...p, language, extraLanguages } });
        setListing(result);
        setHasResults(true);
        toast.success(t("toast.ready"));
      } catch (err) {
        const msg = err instanceof Error ? err.message : "";
        toast.error(msg.includes("LIMIT_REACHED") ? t("toast.limitReached") : msg || t("toast.generateFailed"));
      } finally {
        setIsGenerating(false);
      }
    },
    [generateManual, language, extraLanguages, t]
  );

  const handleCreate = useCallback(() => {
    if (!previewUrl) {
      toast.error(t("toast.uploadFirst"));
      return;
    }
    if (imageDataUrl) {
      void runGeneration(imageDataUrl);
      return;
    }
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);
      setHasResults(true);
      toast.success(t("toast.ready"));
    }, 1200);
  }, [previewUrl, imageDataUrl, runGeneration, t]);

  const benefitsText = current.benefits.join("\n");
  const seoText = current.seoTags.join(", ");
  const olxPromTagsText = [...current.olxTags, ...current.promTags].join(", ");
  const variantsText = current.variants
    .map((v) => `${v.label}\n${v.title}\n${v.post}`)
    .join("\n\n");
  const allText = `${current.title}\n\n${current.shortDescription}\n\n${current.fullDescription}`;

  return (
    <div className="min-h-screen bg-background pb-10 text-ink antialiased">
      <div className="mx-auto max-w-[414px] px-4 pt-5">
        {/* Header */}
        <header className="mb-5">
          <div className="mb-3 flex items-center justify-between gap-2">
            <div className="grid size-10 shrink-0 place-items-center rounded-xl bg-brand font-display text-base font-bold text-brand-foreground">
              F
            </div>
            <div className="flex items-center gap-2">
              {!user && <AccountBar />}
              <LanguageSwitcher />
            </div>
          </div>
          {user && <AccountBar />}
          <h1 className="font-display text-2xl font-extrabold tracking-tight text-ink">
            Fast<span className="text-brand">List</span>
          </h1>
          <p className="mt-1 text-[13px] leading-snug text-ink/60 text-balance">
            {t("app.tagline")}
          </p>
        </header>

        {/* Upload + Actions */}
        <section className="rounded-2xl border border-border bg-card p-4 shadow-sm">
          <h2 className="mb-3 font-display text-lg font-bold tracking-tight text-ink">
            {t("upload.heading")}
          </h2>
          <div
            className="relative grid aspect-[4/3] w-full cursor-pointer place-items-center overflow-hidden rounded-xl border-2 border-dashed border-brand/30 bg-sand transition-colors hover:border-brand/50"
            onClick={handleUploadClick}
          >
            {previewUrl ? (
              <img
                src={previewUrl}
                alt={t("upload.previewAlt")}
                className="h-full w-full object-cover"
                width={1024}
                height={768}
              />
            ) : (
              <span className="flex flex-col items-center gap-2 text-ink/50">
                <Upload className="size-7 text-brand/60" />
                <span className="text-xs font-medium">
                  {t("upload.dropHint")}
                </span>
                <span className="text-[10px] text-ink/40">
                  {t("upload.formats")}
                </span>
              </span>
            )}
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="sr-only"
            onChange={handleFileChange}
            aria-label={t("upload.inputLabel")}
          />

          <div className="mt-3 space-y-2.5">
            <button
              onClick={() => setManualOpen(true)}
              disabled={isGenerating}
              className="flex w-full items-center justify-between rounded-lg border border-brand/30 bg-brand/5 px-4 py-3 text-sm font-semibold text-brand transition-colors hover:bg-brand/10 active:scale-[0.99] disabled:opacity-60"
            >
              <span className="flex items-center gap-2">
                <PencilLine className="size-4" />
                {t("upload.manual")}
              </span>
              <span className="text-xs text-brand/60">{t("upload.manualHint")}</span>
            </button>

            <button
              onClick={handleUploadClick}
              className="flex w-full items-center justify-between rounded-lg border border-input bg-card px-4 py-3 text-sm font-semibold text-ink transition-colors hover:bg-sand active:scale-[0.99]"
            >
              <span className="flex items-center gap-2">
                <Upload className="size-4 text-brand" />
                {t("upload.button")}
              </span>
              <span className="text-xs text-ink/40">{t("upload.formats")}</span>
            </button>

            <button
              onClick={() => {
                setScanMode("photo");
                setScannerOpen(true);
              }}
              disabled={isGenerating}
              className="flex w-full items-center justify-between rounded-lg border border-brand/30 bg-brand/5 px-4 py-3 text-sm font-semibold text-brand transition-colors hover:bg-brand/10 active:scale-[0.99] disabled:opacity-60"
            >
              <span className="flex items-center gap-2">
                <ScanLine className="size-4" />
                {t("upload.scanner")}
              </span>
              <span className="text-xs text-brand/60">
                {t("upload.scannerHint")}
              </span>
            </button>

            <button
              onClick={() => {
                setScanMode("barcode");
                setScannerOpen(true);
              }}
              disabled={isGenerating}
              className="flex w-full items-center justify-between rounded-lg border border-brand/30 bg-brand/5 px-4 py-3 text-sm font-semibold text-brand transition-colors hover:bg-brand/10 active:scale-[0.99] disabled:opacity-60"
            >
              <span className="flex items-center gap-2">
                <Barcode className="size-4" />
                {t("upload.barcode")}
              </span>
              <span className="text-xs text-brand/60">
                {t("upload.barcodeHint")}
              </span>
            </button>


            {barcodeInfo && (
              <p className="rounded-lg bg-sand px-3 py-2 text-[11px] text-ink/60">
                {barcodeInfo}
              </p>
            )}

            <OutputLanguages
              primary={language}
              selected={extraLanguages}
              onChange={setExtraLanguages}
            />

            <button
              onClick={handleCreate}
              disabled={isGenerating}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-brand px-4 py-3.5 text-sm font-bold text-brand-foreground shadow-sm shadow-brand/25 transition hover:bg-brand-deep active:scale-[0.99] disabled:opacity-70"
            >
              {isGenerating ? (
                <>
                  <span className="size-4 animate-spin rounded-full border-2 border-brand-foreground/30 border-t-brand-foreground" />
                  {t("upload.creating")}
                </>
              ) : (
                <>
                  <Sparkles className="size-4" />
                  {t("upload.create")}
                </>
              )}
            </button>
          </div>
        </section>

        {/* Results */}
        {hasResults && (
          <section className="mt-7">
            <div className="mb-3 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <h2 className="font-display text-lg font-bold text-ink">
                  {t("results.heading")}
                </h2>
                <span className="rounded-full bg-brand/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-brand">
                  AI
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setLabelOpen(true)}
                  className="flex shrink-0 items-center gap-1.5 rounded-lg border border-brand/40 px-3 py-1.5 text-[11px] font-bold text-brand transition hover:bg-brand/5 active:scale-95"
                >
                  <Printer className="size-3.5" />
                  <span>{t("label.print")}</span>
                </button>
                <CopyAllButton text={allText} />
              </div>
            </div>

            <div className="space-y-3">
              <ResultCard
                title={t("results.title")}
                copyText={current.title}
                copyLabel={t("results.title")}
                delay={0}
              >
                <h3 className="font-display text-xl font-bold leading-tight text-ink">
                  {current.title}
                </h3>
                <p className="mt-2 text-[13px] leading-relaxed text-ink/70">
                  {current.shortDescription}
                </p>
              </ResultCard>

              <ResultCard
                title={t("results.fullDescription")}
                copyText={current.fullDescription}
                delay={60}
              >
                <p className="text-[13px] leading-relaxed text-ink/80">
                  {current.fullDescription}
                </p>
              </ResultCard>

              <ResultCard
                title={t("results.price")}
                copyText={current.price}
                delay={120}
              >
                <p className="font-display text-2xl font-bold tracking-tight text-brand">
                  {current.price}
                </p>
              </ResultCard>

              <ResultCard
                title={t("results.marketTags")}
                copyText={olxPromTagsText}
                delay={180}
              >
                <div className="space-y-2">
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-wider text-ink/40">
                      OLX
                    </p>
                    <div className="mt-1 flex flex-wrap gap-1.5">
                      {current.olxTags.map((tag) => (
                        <span
                          key={`olx-${tag}`}
                          className="rounded-full bg-brand/10 px-2.5 py-1 text-[11px] font-medium text-brand"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-wider text-ink/40">
                      Prom
                    </p>
                    <div className="mt-1 flex flex-wrap gap-1.5">
                      {current.promTags.map((tag) => (
                        <span
                          key={`prom-${tag}`}
                          className="rounded-full bg-muted px-2.5 py-1 text-[11px] font-medium text-ink/80"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </ResultCard>

              <ResultCard
                title={t("results.seoTags")}
                copyText={seoText}
                delay={240}
              >
                <div className="flex flex-wrap gap-1.5">
                  {current.seoTags.map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full bg-brand/10 px-2.5 py-1 text-[11px] font-medium text-brand"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </ResultCard>

              <ResultCard
                title={t("results.benefits")}
                copyText={benefitsText}
                delay={300}
              >
                <ul className="space-y-1.5 text-[13px] text-ink/80">
                  {current.benefits.map((benefit) => (
                    <li key={benefit} className="flex items-start gap-2">
                      <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-brand" />
                      {benefit}
                    </li>
                  ))}
                </ul>
              </ResultCard>

              {/* Platform selector */}
              <div
                className="animate-result-rise rounded-xl border border-border bg-card p-4 shadow-sm"
                style={{ animationDelay: "360ms" }}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <h3 className="text-[11px] font-semibold uppercase tracking-wider text-ink/45">
                      {t("results.postText")}
                    </h3>
                    <div className="mt-2 flex flex-wrap gap-2">
                      {(Object.keys(platformLabels) as Platform[]).map((key) => (
                        <button
                          key={key}
                          onClick={() => setPlatform(key)}
                          className={`rounded-full px-3 py-1 text-[11px] font-semibold transition ${
                            platform === key
                              ? "bg-brand text-brand-foreground shadow-sm shadow-brand/20"
                              : "bg-sand text-ink/70 hover:bg-brand/10 hover:text-brand"
                          }`}
                        >
                          {platformLabels[key]}
                        </button>
                      ))}
                    </div>
                    <div className="mt-3 rounded-xl bg-ink/[0.03] p-3">
                      <p className="whitespace-pre-line text-[13px] leading-relaxed text-ink/80">
                        {current.platformPosts[platform]}
                      </p>
                    </div>
                  </div>
                  <CopyButton
                    text={current.platformPosts[platform]}
                    label={platformLabels[platform]}
                  />
                </div>
              </div>

              {/* Other languages */}
              {current.variants.length > 0 && (
                <ResultCard
                  title={t("results.translations")}
                  copyText={variantsText}
                  delay={420}
                >
                  <div className="space-y-3">
                    {current.variants.map((variant) => (
                      <div
                        key={variant.code}
                        className="rounded-xl bg-ink/[0.03] p-3"
                      >
                        <p className="text-[11px] font-semibold uppercase tracking-wider text-ink/60">
                          {LANGUAGE_BY_CODE[variant.code]?.flag ?? "🌐"}{" "}
                          {variant.label}
                        </p>
                        <p className="mt-1 text-[13px] font-semibold text-ink">
                          {variant.title}
                        </p>
                        <p className="mt-1 whitespace-pre-line text-[13px] leading-relaxed text-ink/80">
                          {variant.post}
                        </p>
                      </div>
                    ))}
                  </div>
                </ResultCard>
              )}
            </div>
          </section>
        )}

        {/* Pricing */}
        <section className="mt-7">
          <h2 className="mb-3 font-display text-lg font-bold text-ink">
            {t("pricing.heading")}
          </h2>
          <div className="space-y-3">
            {tariffs.map((tariff) => (
              <TariffCard
                key={tariff.id}
                tariff={tariff}
                onSelect={() => {
                  if (tariff.id === "free") {
                    if (!user) navigate({ to: "/auth" });
                    return;
                  }
                  if (!user) {
                    toast.info(t("checkout.loginFirst"));
                    navigate({ to: "/auth" });
                    return;
                  }
                  setCheckoutPlan({
                    id: tariff.id as CheckoutPlan["id"],
                    name: tariff.name,
                    price: tariff.price,
                    period: tariff.period,
                    description: tariff.description,
                    trialDays: tariff.trialDays,
                  });
                }}
              />
            ))}
          </div>
        </section>

        <p className="mt-8 text-center text-[11px] text-ink/40">
          {t("footer.note")}
        </p>
      </div>

      {manualOpen && (
        <ManualEntryModal
          onClose={() => setManualOpen(false)}
          onSave={handleManualSave}
          onGenerate={(p) => void handleManualGenerate(p)}
        />
      )}

      {scannerOpen && (
        <Suspense fallback={null}>
          <CameraScanner
            mode={scanMode}
            onBarcode={handleBarcode}
            onCapture={handleScanCapture}
            onClose={() => setScannerOpen(false)}
          />
        </Suspense>
      )}

      {labelOpen && (
        <Suspense fallback={null}>
          <PrintLabelModal
            listing={current}
            barcode={lastBarcode}
            onClose={() => setLabelOpen(false)}
          />
        </Suspense>
      )}

      {checkoutPlan && user && (
        <Suspense fallback={null}>
          <CheckoutModal
            plan={checkoutPlan}
            email={user.email ?? ""}
            onClose={() => setCheckoutPlan(null)}
          />
        </Suspense>
      )}
    </div>
  );
}
